:github_url: https://github.com/python-telegram-bot/python-telegram-bot/blob/master/telegram/ext/pollhandler.py

telegram.ext.PollHandler
========================

.. autoclass:: telegram.ext.PollHandler
    :members:
    :show-inheritance:
