:github_url: https://github.com/python-telegram-bot/python-telegram-bot/blob/master/telegram/ext/callbackcontext.py

telegram.ext.CallbackContext
============================

.. autoclass:: telegram.ext.CallbackContext
    :members:
