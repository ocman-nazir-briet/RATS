:github_url: https://github.com/python-telegram-bot/python-telegram-bot/blob/master/telegram/ext/chatjoinrequesthandler.py

telegram.ext.ChatJoinRequestHandler
===================================

.. autoclass:: telegram.ext.ChatJoinRequestHandler
    :members:
    :show-inheritance:
