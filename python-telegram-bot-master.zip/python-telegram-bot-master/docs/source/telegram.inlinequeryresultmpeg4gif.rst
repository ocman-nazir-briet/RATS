:github_url: https://github.com/python-telegram-bot/python-telegram-bot/blob/master/telegram/inline/inlinequeryresultmpeg4gif.py

telegram.InlineQueryResultMpeg4Gif
==================================

.. autoclass:: telegram.InlineQueryResultMpeg4Gif
    :members:
    :show-inheritance:
