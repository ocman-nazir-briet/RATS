:github_url: https://github.com/python-telegram-bot/python-telegram-bot/blob/master/telegram/inline/inlinequeryresultvenue.py

telegram.InlineQueryResultVenue
===============================

.. autoclass:: telegram.InlineQueryResultVenue
    :members:
    :show-inheritance:
