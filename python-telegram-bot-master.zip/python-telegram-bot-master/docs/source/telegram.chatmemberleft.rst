:github_url: https://github.com/python-telegram-bot/python-telegram-bot/blob/master/telegram/chatmember.py

telegram.ChatMemberLeft
=======================

.. autoclass:: telegram.ChatMemberLeft
    :members:
    :show-inheritance:
