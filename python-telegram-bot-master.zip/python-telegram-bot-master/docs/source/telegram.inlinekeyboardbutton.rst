:github_url: https://github.com/python-telegram-bot/python-telegram-bot/blob/master/telegram/inline/inlinekeyboardbutton.py

telegram.InlineKeyboardButton
=============================

.. autoclass:: telegram.InlineKeyboardButton
    :members:
    :show-inheritance:
