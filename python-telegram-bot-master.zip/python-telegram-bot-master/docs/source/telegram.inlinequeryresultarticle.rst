:github_url: https://github.com/python-telegram-bot/python-telegram-bot/blob/master/telegram/inline/inlinequeryresultarticle.py

telegram.InlineQueryResultArticle
=================================

.. autoclass:: telegram.InlineQueryResultArticle
    :members:
    :show-inheritance:
