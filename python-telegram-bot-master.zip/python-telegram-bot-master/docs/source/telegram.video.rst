:github_url: https://github.com/python-telegram-bot/python-telegram-bot/blob/master/telegram/files/video.py

telegram.Video
==============

.. autoclass:: telegram.Video
    :members:
    :show-inheritance:
