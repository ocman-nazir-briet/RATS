:github_url: https://github.com/python-telegram-bot/python-telegram-bot/blob/master/telegram/ext/utils/promise.py

telegram.ext.utils.promise.Promise
==================================

.. autoclass:: telegram.ext.utils.promise.Promise
    :members:
    :show-inheritance:
