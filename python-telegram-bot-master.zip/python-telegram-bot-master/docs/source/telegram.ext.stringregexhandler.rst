:github_url: https://github.com/python-telegram-bot/python-telegram-bot/blob/master/telegram/ext/stringregexhandler.py

telegram.ext.StringRegexHandler
===============================

.. autoclass:: telegram.ext.StringRegexHandler
    :members:
    :show-inheritance:
