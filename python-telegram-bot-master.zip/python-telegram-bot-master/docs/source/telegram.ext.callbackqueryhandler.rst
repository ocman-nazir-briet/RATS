:github_url: https://github.com/python-telegram-bot/python-telegram-bot/blob/master/telegram/ext/callbackqueryhandler.py

telegram.ext.CallbackQueryHandler
=================================

.. autoclass:: telegram.ext.CallbackQueryHandler
    :members:
    :show-inheritance:
