:github_url: https://github.com/python-telegram-bot/python-telegram-bot/blob/master/telegram/chatmemberupdated.py

telegram.ChatMemberUpdated
==========================

.. autoclass:: telegram.ChatMemberUpdated
    :members:
    :show-inheritance:
