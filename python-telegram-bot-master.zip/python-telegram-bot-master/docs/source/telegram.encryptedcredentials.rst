:github_url: https://github.com/python-telegram-bot/python-telegram-bot/blob/master/telegram/passport/credentials.py

telegram.EncryptedCredentials
=============================

.. autoclass:: telegram.EncryptedCredentials
    :members:
    :show-inheritance:
