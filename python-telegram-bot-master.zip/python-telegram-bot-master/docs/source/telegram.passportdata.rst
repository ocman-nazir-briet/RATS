:github_url: https://github.com/python-telegram-bot/python-telegram-bot/blob/master/telegram/passport/passportdata.py

telegram.PassportData
=====================

.. autoclass:: telegram.PassportData
    :members:
    :show-inheritance:
