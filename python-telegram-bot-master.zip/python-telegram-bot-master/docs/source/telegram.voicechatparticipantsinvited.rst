:github_url: https://github.com/python-telegram-bot/python-telegram-bot/blob/master/telegram/voicechat.py

telegram.VoiceChatParticipantsInvited
=====================================

.. autoclass:: telegram.VoiceChatParticipantsInvited
    :members:
    :show-inheritance:

