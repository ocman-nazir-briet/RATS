:github_url: https://github.com/python-telegram-bot/python-telegram-bot/blob/master/telegram/passport/passportelementerrors.py

telegram.PassportElementErrorTranslationFiles
=============================================

.. autoclass:: telegram.PassportElementErrorTranslationFiles
    :members:
    :show-inheritance:
