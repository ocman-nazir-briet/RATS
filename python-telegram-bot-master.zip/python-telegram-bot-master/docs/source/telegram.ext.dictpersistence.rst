:github_url: https://github.com/python-telegram-bot/python-telegram-bot/blob/master/telegram/ext/dictpersistence.py

telegram.ext.DictPersistence
============================

.. autoclass:: telegram.ext.DictPersistence
    :members:
    :show-inheritance:
