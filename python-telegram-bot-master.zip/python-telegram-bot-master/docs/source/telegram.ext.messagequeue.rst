:github_url: https://github.com/python-telegram-bot/python-telegram-bot/blob/master/telegram/ext/messagequeue.py

telegram.ext.MessageQueue
=========================

.. autoclass:: telegram.ext.MessageQueue
    :members:
    :show-inheritance:
    :special-members:
