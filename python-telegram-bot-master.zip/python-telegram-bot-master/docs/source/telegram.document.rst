:github_url: https://github.com/python-telegram-bot/python-telegram-bot/blob/master/telegram/files/document.py

telegram.Document
=================

.. autoclass:: telegram.Document
    :members:
    :show-inheritance:
