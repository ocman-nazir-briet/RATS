:github_url: https://github.com/python-telegram-bot/python-telegram-bot/blob/master/telegram/ext/filters.py

telegram.ext.filters Module
===========================

.. automodule:: telegram.ext.filters
    :members:
    :show-inheritance:
