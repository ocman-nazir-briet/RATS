:github_url: https://github.com/python-telegram-bot/python-telegram-bot/blob/master/telegram/userprofilephotos.py

telegram.UserProfilePhotos
==========================

.. autoclass:: telegram.UserProfilePhotos
    :members:
    :show-inheritance:
