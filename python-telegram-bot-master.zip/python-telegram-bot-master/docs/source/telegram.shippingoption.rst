:github_url: https://github.com/python-telegram-bot/python-telegram-bot/blob/master/telegram/payment/shippingoption.py

telegram.ShippingOption
=======================

.. autoclass:: telegram.ShippingOption
    :members:
    :show-inheritance:
