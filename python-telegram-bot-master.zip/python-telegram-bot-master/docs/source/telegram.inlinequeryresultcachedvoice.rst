:github_url: https://github.com/python-telegram-bot/python-telegram-bot/blob/master/telegram/inline/inlinequeryresultcachedvoice.py

telegram.InlineQueryResultCachedVoice
=====================================

.. autoclass:: telegram.InlineQueryResultCachedVoice
    :members:
    :show-inheritance:
