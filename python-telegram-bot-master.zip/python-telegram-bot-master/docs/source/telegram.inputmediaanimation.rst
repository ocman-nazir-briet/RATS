:github_url: https://github.com/python-telegram-bot/python-telegram-bot/blob/master/telegram/files/inputmedia.py

telegram.InputMediaAnimation
============================

.. autoclass:: telegram.InputMediaAnimation
    :members:
    :show-inheritance:
