:github_url: https://github.com/python-telegram-bot/python-telegram-bot/blob/master/telegram/botcommandscope.py

telegram.BotCommandScopeAllGroupChats
=======================================

.. autoclass:: telegram.BotCommandScopeAllGroupChats
    :members:
    :show-inheritance: