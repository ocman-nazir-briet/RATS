:github_url: https://github.com/python-telegram-bot/python-telegram-bot/blob/master/telegram/replykeyboardmarkup.py

telegram.ReplyKeyboardMarkup
============================

.. autoclass:: telegram.ReplyKeyboardMarkup
    :members:
    :show-inheritance:
