:github_url: https://github.com/python-telegram-bot/python-telegram-bot/blob/master/telegram/voicechat.py

telegram.VoiceChatStarted
=========================

.. autoclass:: telegram.VoiceChatStarted
    :members:
    :show-inheritance:

