:github_url: https://github.com/python-telegram-bot/python-telegram-bot/blob/master/telegram/forcereply.py

telegram.ForceReply
===================

.. autoclass:: telegram.ForceReply
    :members:
    :show-inheritance:
