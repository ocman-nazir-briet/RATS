:github_url: https://github.com/python-telegram-bot/python-telegram-bot/blob/master/telegram/keyboardbuttonpolltype.py

telegram.KeyboardButtonPollType
===============================

.. autoclass:: telegram.KeyboardButtonPollType
    :members:
    :show-inheritance:
