:github_url: https://github.com/python-telegram-bot/python-telegram-bot/blob/master/telegram/ext/chatmemberhandler.py

telegram.ext.ChatMemberHandler
==============================

.. autoclass:: telegram.ext.ChatMemberHandler
    :members:
    :show-inheritance:
