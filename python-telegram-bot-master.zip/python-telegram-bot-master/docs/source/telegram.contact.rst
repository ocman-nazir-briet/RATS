:github_url: https://github.com/python-telegram-bot/python-telegram-bot/blob/master/telegram/files/contact.py

telegram.Contact
================

.. autoclass:: telegram.Contact
    :members:
    :show-inheritance:
