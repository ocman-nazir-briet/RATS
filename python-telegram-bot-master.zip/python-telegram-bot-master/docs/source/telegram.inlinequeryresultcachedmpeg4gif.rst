:github_url: https://github.com/python-telegram-bot/python-telegram-bot/blob/master/telegram/inline/inlinequeryresultcachedmpeg4gif.py

telegram.InlineQueryResultCachedMpeg4Gif
========================================

.. autoclass:: telegram.InlineQueryResultCachedMpeg4Gif
    :members:
    :show-inheritance:
