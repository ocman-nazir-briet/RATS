:github_url: https://github.com/python-telegram-bot/python-telegram-bot/blob/master/telegram/utils/types.py

telegram.utils.types Module
===========================

.. automodule:: telegram.utils.types
    :members:
    :show-inheritance:
