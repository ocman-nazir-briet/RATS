:github_url: https://github.com/python-telegram-bot/python-telegram-bot/blob/master/telegram/update.py

telegram.Update
===============

.. autoclass:: telegram.Update
    :members:
    :show-inheritance:
