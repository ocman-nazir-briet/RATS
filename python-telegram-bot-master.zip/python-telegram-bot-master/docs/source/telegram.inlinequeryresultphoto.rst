:github_url: https://github.com/python-telegram-bot/python-telegram-bot/blob/master/telegram/inline/inlinequeryresultphoto.py

telegram.InlineQueryResultPhoto
===============================

.. autoclass:: telegram.InlineQueryResultPhoto
    :members:
    :show-inheritance:
