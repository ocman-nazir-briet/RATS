:github_url: https://github.com/python-telegram-bot/python-telegram-bot/blob/master/telegram/ext/picklepersistence.py

telegram.ext.PicklePersistence
==============================

.. autoclass:: telegram.ext.PicklePersistence
    :members:
    :show-inheritance:
