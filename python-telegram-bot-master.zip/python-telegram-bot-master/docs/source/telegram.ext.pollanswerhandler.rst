:github_url: https://github.com/python-telegram-bot/python-telegram-bot/blob/master/telegram/ext/pollanswerhandler.py

telegram.ext.PollAnswerHandler
==============================

.. autoclass:: telegram.ext.PollAnswerHandler
    :members:
    :show-inheritance:
