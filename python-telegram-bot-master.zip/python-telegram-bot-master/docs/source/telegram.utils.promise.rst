telegram.utils.promise.Promise
==============================

.. py:class:: telegram.utils.promise.Promise

   Shortcut for :class:`telegram.ext.utils.promise.Promise`.

   .. deprecated:: 13.2
      Use :class:`telegram.ext.utils.promise.Promise` instead.
