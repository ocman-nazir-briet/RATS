:github_url: https://github.com/python-telegram-bot/python-telegram-bot/blob/master/telegram/constants.py

telegram.constants Module
=========================

.. automodule:: telegram.constants
    :members:
    :show-inheritance:
