:github_url: https://github.com/python-telegram-bot/python-telegram-bot/blob/master/telegram/ext/messagehandler.py

telegram.ext.MessageHandler
===========================

.. autoclass:: telegram.ext.MessageHandler
    :members:
    :show-inheritance:
