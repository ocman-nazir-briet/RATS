:github_url: https://github.com/python-telegram-bot/python-telegram-bot/blob/master/telegram/inline/inlinequeryresultcacheddocument.py

telegram.InlineQueryResultCachedDocument
========================================

.. autoclass:: telegram.InlineQueryResultCachedDocument
    :members:
    :show-inheritance:
