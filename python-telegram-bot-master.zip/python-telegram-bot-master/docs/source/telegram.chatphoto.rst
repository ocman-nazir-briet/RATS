:github_url: https://github.com/python-telegram-bot/python-telegram-bot/blob/master/telegram/files/chatphoto.py

telegram.ChatPhoto
==================

.. autoclass:: telegram.ChatPhoto
    :members:
    :show-inheritance:
