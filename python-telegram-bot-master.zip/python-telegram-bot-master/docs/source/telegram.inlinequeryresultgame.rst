:github_url: https://github.com/python-telegram-bot/python-telegram-bot/blob/master/telegram/inline/inlinequeryresultgame.py

telegram.InlineQueryResultGame
==============================

.. autoclass:: telegram.InlineQueryResultGame
    :members:
    :show-inheritance:
