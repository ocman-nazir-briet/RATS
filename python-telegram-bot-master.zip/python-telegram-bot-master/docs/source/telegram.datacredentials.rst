:github_url: https://github.com/python-telegram-bot/python-telegram-bot/blob/master/telegram/passport/credentials.py

telegram.DataCredentials
========================

.. autoclass:: telegram.DataCredentials
    :members:
    :show-inheritance:
