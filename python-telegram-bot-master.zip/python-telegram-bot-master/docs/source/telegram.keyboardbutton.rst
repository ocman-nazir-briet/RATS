:github_url: https://github.com/python-telegram-bot/python-telegram-bot/blob/master/telegram/keyboardbutton.py

telegram.KeyboardButton
=======================

.. autoclass:: telegram.KeyboardButton
    :members:
    :show-inheritance:
