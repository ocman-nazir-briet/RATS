:github_url: https://github.com/python-telegram-bot/python-telegram-bot/blob/master/telegram/ext/shippingqueryhandler.py

telegram.ext.ShippingQueryHandler
=================================

.. autoclass:: telegram.ext.ShippingQueryHandler
    :members:
    :show-inheritance:
