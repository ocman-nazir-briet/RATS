# SpyNoteShell
Simple Python tool for backdooring apks files (with meterpreter or shell of Metasploit)

***
USE
./spynoteshell.py /path/to/apk-to-backdoor
***
REQUIREMENTS:
- apktool;
- python;
- signapk;
- Metasploit Framework (https://rapid7.com/products/metasploit/);
- Java SDK;
- Java;

ADDITIONAL FILES:
- SpyNoteShell.cna - This is the same script, but create for Armitage. Just go to Scripts >>> load >>> SpyNoteShell folder >>> choose SpyNoteSHell.cna and that's it! You'll see on the top bar a new option named SpyNoteShell with others info into it, just play around :) <br>
- persistent.sh - This is a bash file made for Post Exploitation. After get a meterpreter/shell, just upload it to a folder were you have permission (just try around) and upload it.<br>
After drop into the system's shell by typing:  shell<br>
Now, navigate to the location of the script:<br>
cd /<br>
cd /path/to/thefile/</br>
Now its time for EXECUTION. Type:<br>
sh anything.sh

ONLY FOR EDUCATIONAL/ STUDY/ LEGAL/ AUTHORIZED/ PENTISTING PURPOSES!!
