﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class FSettings
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim DataGridViewCellStyle1 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle2 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Me.ProgressBar1 = New SpyNote_V6._4.SN.ThemeProgressBar()
        Me.PNLERRORS = New System.Windows.Forms.Panel()
        Me.LBER = New System.Windows.Forms.Label()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.BtnOK = New SpyNote_V6._4.SN.ThemeButton()
        Me.ThemeTabControl1 = New SpyNote_V6._4.SN.ThemeTabControl()
        Me.TabPage1 = New System.Windows.Forms.TabPage()
        Me.PINFO = New System.Windows.Forms.Panel()
        Me.ViewManager = New System.Windows.Forms.DataGridView()
        Me.Column1 = New System.Windows.Forms.DataGridViewImageColumn()
        Me.Column2 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.VisualStudioHorizontalScrollBar1 = New SpyNote_V6._4.SN.VisualStudioHorizontalScrollBar()
        Me.VisualStudioVerticalScrollBar1 = New SpyNote_V6._4.SN.VisualStudioVerticalScrollBar()
        Me.TabPage2 = New System.Windows.Forms.TabPage()
        Me.PanelSystem = New System.Windows.Forms.Panel()
        Me.ThemeSeparator3 = New SpyNote_V6._4.SN.ThemeSeparator()
        Me.TrackSystem = New SpyNote_V6._4.SN.Track()
        Me.LabelSystem = New System.Windows.Forms.Label()
        Me.PanelNotification = New System.Windows.Forms.Panel()
        Me.ThemeSeparator2 = New SpyNote_V6._4.SN.ThemeSeparator()
        Me.TrackNotification = New SpyNote_V6._4.SN.Track()
        Me.LabelNotification = New System.Windows.Forms.Label()
        Me.PanelMedia = New System.Windows.Forms.Panel()
        Me.ThemeSeparator1 = New SpyNote_V6._4.SN.ThemeSeparator()
        Me.TrackMedia = New SpyNote_V6._4.SN.Track()
        Me.LabelMedia = New System.Windows.Forms.Label()
        Me.PanelRingtone = New System.Windows.Forms.Panel()
        Me.TSEP1 = New SpyNote_V6._4.SN.ThemeSeparator()
        Me.TrackRingtone = New SpyNote_V6._4.SN.Track()
        Me.LabelRingtone = New System.Windows.Forms.Label()
        Me.TabPage3 = New System.Windows.Forms.TabPage()
        Me.PanelBar = New System.Windows.Forms.Panel()
        Me.ThemeSeparator5 = New SpyNote_V6._4.SN.ThemeSeparator()
        Me.ThemeSeparator4 = New SpyNote_V6._4.SN.ThemeSeparator()
        Me.LabBarWifirest = New System.Windows.Forms.Label()
        Me.LabBarWifiDisconnect = New System.Windows.Forms.Label()
        Me.LabBarWifiConnected = New System.Windows.Forms.Label()
        Me.LabBarMobileData = New System.Windows.Forms.Label()
        Me.LabBarGps = New System.Windows.Forms.Label()
        Me.LabBarBluetooth = New System.Windows.Forms.Label()
        Me.LabBarSilent = New System.Windows.Forms.Label()
        Me.LabBarVibrate = New System.Windows.Forms.Label()
        Me.LabBarNormal = New System.Windows.Forms.Label()
        Me.BtnBarWifirest = New SpyNote_V6._4.SN.ThemeBtnBar()
        Me.BtnBarWifiDisconnect = New SpyNote_V6._4.SN.ThemeBtnBar()
        Me.BtnBarWifiConnected = New SpyNote_V6._4.SN.ThemeBtnBar()
        Me.BtnBarMobileData = New SpyNote_V6._4.SN.ThemeBtnBar()
        Me.BtnBarGps = New SpyNote_V6._4.SN.ThemeBtnBar()
        Me.BtnBarBluetooth = New SpyNote_V6._4.SN.ThemeBtnBar()
        Me.BtnBarSilent = New SpyNote_V6._4.SN.ThemeBtnBar()
        Me.BtnBarVibrate = New SpyNote_V6._4.SN.ThemeBtnBar()
        Me.BtnBarNormal = New SpyNote_V6._4.SN.ThemeBtnBar()
        Me.TabPage4 = New System.Windows.Forms.TabPage()
        Me.PNLAdmin = New System.Windows.Forms.Panel()
        Me.LABKEY = New System.Windows.Forms.Label()
        Me.LABresetPassword = New System.Windows.Forms.Label()
        Me.BRNresetPassword = New SpyNote_V6._4.SN.ThemeButton()
        Me.LABwipeData = New System.Windows.Forms.Label()
        Me.BTNwipeData = New SpyNote_V6._4.SN.ThemeButton()
        Me.LBFLlockNow = New System.Windows.Forms.Label()
        Me.BTNlockNow = New SpyNote_V6._4.SN.ThemeButton()
        Me.TScrolls = New System.Windows.Forms.Timer(Me.components)
        Me.TProgressBar = New System.Windows.Forms.Timer(Me.components)
        Me.Trans = New System.Windows.Forms.Timer(Me.components)
        Me.PNLERRORS.SuspendLayout()
        Me.Panel1.SuspendLayout()
        Me.ThemeTabControl1.SuspendLayout()
        Me.TabPage1.SuspendLayout()
        Me.PINFO.SuspendLayout()
        CType(Me.ViewManager, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.TabPage2.SuspendLayout()
        Me.PanelSystem.SuspendLayout()
        Me.PanelNotification.SuspendLayout()
        Me.PanelMedia.SuspendLayout()
        Me.PanelRingtone.SuspendLayout()
        Me.TabPage3.SuspendLayout()
        Me.PanelBar.SuspendLayout()
        Me.TabPage4.SuspendLayout()
        Me.PNLAdmin.SuspendLayout()
        Me.SuspendLayout()
        '
        'ProgressBar1
        '
        Me.ProgressBar1.Animated = True
        Me.ProgressBar1.Colour0 = System.Drawing.Color.FromArgb(CType(CType(140, Byte), Integer), CType(CType(140, Byte), Integer), CType(CType(140, Byte), Integer))
        Me.ProgressBar1.Colour1 = System.Drawing.Color.FromArgb(CType(CType(140, Byte), Integer), CType(CType(140, Byte), Integer), CType(CType(140, Byte), Integer))
        Me.ProgressBar1.Customization = "AAAAAAAAAAAAAAAAAAAAAA=="
        Me.ProgressBar1.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.ProgressBar1.Font = New System.Drawing.Font("Verdana", 8.0!)
        Me.ProgressBar1.Image = Nothing
        Me.ProgressBar1.Location = New System.Drawing.Point(0, 434)
        Me.ProgressBar1.Maximum = 100
        Me.ProgressBar1.Minimum = 0
        Me.ProgressBar1.Name = "ProgressBar1"
        Me.ProgressBar1.NoRounding = False
        Me.ProgressBar1.Size = New System.Drawing.Size(343, 10)
        Me.ProgressBar1.TabIndex = 2
        Me.ProgressBar1.Text = "ThemeProgressBar1"
        Me.ProgressBar1.Transparent = False
        Me.ProgressBar1.Value = 0
        '
        'PNLERRORS
        '
        Me.PNLERRORS.BackColor = System.Drawing.Color.FromArgb(CType(CType(45, Byte), Integer), CType(CType(45, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.PNLERRORS.Controls.Add(Me.LBER)
        Me.PNLERRORS.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.PNLERRORS.Location = New System.Drawing.Point(0, 415)
        Me.PNLERRORS.Name = "PNLERRORS"
        Me.PNLERRORS.Size = New System.Drawing.Size(343, 19)
        Me.PNLERRORS.TabIndex = 3
        Me.PNLERRORS.Visible = False
        '
        'LBER
        '
        Me.LBER.AutoSize = True
        Me.LBER.Dock = System.Windows.Forms.DockStyle.Left
        Me.LBER.Font = New System.Drawing.Font("Segoe UI Semibold", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LBER.ForeColor = System.Drawing.Color.FromArgb(CType(CType(241, Byte), Integer), CType(CType(241, Byte), Integer), CType(CType(241, Byte), Integer))
        Me.LBER.Location = New System.Drawing.Point(0, 0)
        Me.LBER.Name = "LBER"
        Me.LBER.Size = New System.Drawing.Size(37, 15)
        Me.LBER.TabIndex = 0
        Me.LBER.Text = "Errors"
        '
        'Panel1
        '
        Me.Panel1.Controls.Add(Me.BtnOK)
        Me.Panel1.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.Panel1.Location = New System.Drawing.Point(0, 381)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(343, 34)
        Me.Panel1.TabIndex = 4
        '
        'BtnOK
        '
        Me.BtnOK.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.BtnOK.BackColorDown0_S = System.Drawing.Color.FromArgb(CType(CType(30, Byte), Integer), CType(CType(30, Byte), Integer), CType(CType(30, Byte), Integer))
        Me.BtnOK.BackColorDown1_S = System.Drawing.Color.FromArgb(CType(CType(30, Byte), Integer), CType(CType(30, Byte), Integer), CType(CType(30, Byte), Integer))
        Me.BtnOK.BackColorNone0_S = System.Drawing.Color.FromArgb(CType(CType(37, Byte), Integer), CType(CType(37, Byte), Integer), CType(CType(38, Byte), Integer))
        Me.BtnOK.BackColorNone1_S = System.Drawing.Color.FromArgb(CType(CType(37, Byte), Integer), CType(CType(37, Byte), Integer), CType(CType(38, Byte), Integer))
        Me.BtnOK.BackColorOver0_S = System.Drawing.Color.FromArgb(CType(CType(45, Byte), Integer), CType(CType(45, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.BtnOK.BackColorOver1_S = System.Drawing.Color.FromArgb(CType(CType(45, Byte), Integer), CType(CType(45, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.BtnOK.ButtonBackColorEnabled0_S = System.Drawing.Color.FromArgb(CType(CType(53, Byte), Integer), CType(CType(53, Byte), Integer), CType(CType(60, Byte), Integer))
        Me.BtnOK.ButtonBackColorEnabled1_S = System.Drawing.Color.FromArgb(CType(CType(53, Byte), Integer), CType(CType(53, Byte), Integer), CType(CType(60, Byte), Integer))
        Me.BtnOK.ButtonForColor_S = System.Drawing.Color.FromArgb(CType(CType(174, Byte), Integer), CType(CType(174, Byte), Integer), CType(CType(174, Byte), Integer))
        Me.BtnOK.ButtonForColorEnabled_S = System.Drawing.Color.FromArgb(CType(CType(83, Byte), Integer), CType(CType(83, Byte), Integer), CType(CType(90, Byte), Integer))
        Me.BtnOK.Buttonselected_Color_ForColor_S = System.Drawing.Color.FromArgb(CType(CType(214, Byte), Integer), CType(CType(214, Byte), Integer), CType(CType(214, Byte), Integer))
        Me.BtnOK.Font = New System.Drawing.Font("Segoe UI Semibold", 9.0!)
        Me.BtnOK.ImageAlignment = SpyNote_V6._4.SN.ThemeButton.__ImageAlignment.Left
        Me.BtnOK.ImageChoice = Nothing
        Me.BtnOK.Location = New System.Drawing.Point(232, 2)
        Me.BtnOK.Name = "BtnOK"
        Me.BtnOK.ShowImage = False
        Me.BtnOK.ShowText = True
        Me.BtnOK.Size = New System.Drawing.Size(100, 28)
        Me.BtnOK.TabIndex = 11
        Me.BtnOK.Tag = ""
        Me.BtnOK.Text = "Refresh"
        Me.BtnOK.TextAlignment = System.Drawing.StringAlignment.Center
        Me.BtnOK.ThemeButtonclrBorder_S = System.Drawing.Color.FromArgb(CType(CType(53, Byte), Integer), CType(CType(53, Byte), Integer), CType(CType(60, Byte), Integer))
        Me.BtnOK.ThemeButtonclrBorderactive_S = System.Drawing.Color.FromArgb(CType(CType(56, Byte), Integer), CType(CType(56, Byte), Integer), CType(CType(63, Byte), Integer))
        Me.BtnOK.ThemeButtonclrBorderEnabled_S = System.Drawing.Color.FromArgb(CType(CType(68, Byte), Integer), CType(CType(68, Byte), Integer), CType(CType(75, Byte), Integer))
        '
        'ThemeTabControl1
        '
        Me.ThemeTabControl1.BorderColor_S = System.Drawing.Color.FromArgb(CType(CType(45, Byte), Integer), CType(CType(45, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.ThemeTabControl1.Controls.Add(Me.TabPage1)
        Me.ThemeTabControl1.Controls.Add(Me.TabPage2)
        Me.ThemeTabControl1.Controls.Add(Me.TabPage3)
        Me.ThemeTabControl1.Controls.Add(Me.TabPage4)
        Me.ThemeTabControl1.DefaultBackColor_S = System.Drawing.Color.FromArgb(CType(CType(45, Byte), Integer), CType(CType(45, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.ThemeTabControl1.DefaultColor0_S = System.Drawing.Color.FromArgb(CType(CType(37, Byte), Integer), CType(CType(37, Byte), Integer), CType(CType(38, Byte), Integer))
        Me.ThemeTabControl1.DefaultColor1_S = System.Drawing.Color.FromArgb(CType(CType(37, Byte), Integer), CType(CType(37, Byte), Integer), CType(CType(38, Byte), Integer))
        Me.ThemeTabControl1.DefaultForColor_S = System.Drawing.Color.FromArgb(CType(CType(190, Byte), Integer), CType(CType(190, Byte), Integer), CType(CType(190, Byte), Integer))
        Me.ThemeTabControl1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.ThemeTabControl1.FForColorSelcted_S = System.Drawing.Color.FromArgb(CType(CType(241, Byte), Integer), CType(CType(241, Byte), Integer), CType(CType(241, Byte), Integer))
        Me.ThemeTabControl1.ItemSize = New System.Drawing.Size(25, 25)
        Me.ThemeTabControl1.Location = New System.Drawing.Point(0, 0)
        Me.ThemeTabControl1.MouseOver0_S = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(146, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.ThemeTabControl1.MouseOver1_S = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(146, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.ThemeTabControl1.Multiline = True
        Me.ThemeTabControl1.Name = "ThemeTabControl1"
        Me.ThemeTabControl1.SelectedIndex = 0
        Me.ThemeTabControl1.Size = New System.Drawing.Size(343, 381)
        Me.ThemeTabControl1.TabIndex = 5
        '
        'TabPage1
        '
        Me.TabPage1.BackColor = System.Drawing.Color.FromArgb(CType(CType(37, Byte), Integer), CType(CType(37, Byte), Integer), CType(CType(38, Byte), Integer))
        Me.TabPage1.Controls.Add(Me.PINFO)
        Me.TabPage1.Location = New System.Drawing.Point(4, 54)
        Me.TabPage1.Name = "TabPage1"
        Me.TabPage1.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage1.Size = New System.Drawing.Size(335, 323)
        Me.TabPage1.TabIndex = 0
        Me.TabPage1.Text = "Phone Info"
        '
        'PINFO
        '
        Me.PINFO.Controls.Add(Me.ViewManager)
        Me.PINFO.Controls.Add(Me.VisualStudioHorizontalScrollBar1)
        Me.PINFO.Controls.Add(Me.VisualStudioVerticalScrollBar1)
        Me.PINFO.Dock = System.Windows.Forms.DockStyle.Fill
        Me.PINFO.Location = New System.Drawing.Point(3, 3)
        Me.PINFO.Name = "PINFO"
        Me.PINFO.Size = New System.Drawing.Size(329, 317)
        Me.PINFO.TabIndex = 0
        '
        'ViewManager
        '
        Me.ViewManager.AllowUserToAddRows = False
        Me.ViewManager.AllowUserToDeleteRows = False
        Me.ViewManager.AllowUserToResizeColumns = False
        Me.ViewManager.AllowUserToResizeRows = False
        Me.ViewManager.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells
        Me.ViewManager.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells
        Me.ViewManager.BackgroundColor = System.Drawing.Color.FromArgb(CType(CType(37, Byte), Integer), CType(CType(37, Byte), Integer), CType(CType(38, Byte), Integer))
        Me.ViewManager.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.ViewManager.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.[Single]
        DataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle1.BackColor = System.Drawing.Color.FromArgb(CType(CType(45, Byte), Integer), CType(CType(45, Byte), Integer), CType(CType(48, Byte), Integer))
        DataGridViewCellStyle1.Font = New System.Drawing.Font("Segoe UI Semibold", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle1.ForeColor = System.Drawing.Color.FromArgb(CType(CType(241, Byte), Integer), CType(CType(241, Byte), Integer), CType(CType(241, Byte), Integer))
        DataGridViewCellStyle1.SelectionBackColor = System.Drawing.Color.FromArgb(CType(CType(45, Byte), Integer), CType(CType(45, Byte), Integer), CType(CType(48, Byte), Integer))
        DataGridViewCellStyle1.SelectionForeColor = System.Drawing.Color.FromArgb(CType(CType(241, Byte), Integer), CType(CType(241, Byte), Integer), CType(CType(241, Byte), Integer))
        DataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.ViewManager.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle1
        Me.ViewManager.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.ViewManager.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.Column1, Me.Column2})
        DataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle2.BackColor = System.Drawing.Color.FromArgb(CType(CType(37, Byte), Integer), CType(CType(37, Byte), Integer), CType(CType(38, Byte), Integer))
        DataGridViewCellStyle2.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle2.ForeColor = System.Drawing.Color.FromArgb(CType(CType(170, Byte), Integer), CType(CType(170, Byte), Integer), CType(CType(170, Byte), Integer))
        DataGridViewCellStyle2.SelectionBackColor = System.Drawing.Color.FromArgb(CType(CType(45, Byte), Integer), CType(CType(45, Byte), Integer), CType(CType(48, Byte), Integer))
        DataGridViewCellStyle2.SelectionForeColor = System.Drawing.Color.FromArgb(CType(CType(241, Byte), Integer), CType(CType(241, Byte), Integer), CType(CType(241, Byte), Integer))
        DataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.[False]
        Me.ViewManager.DefaultCellStyle = DataGridViewCellStyle2
        Me.ViewManager.Dock = System.Windows.Forms.DockStyle.Fill
        Me.ViewManager.EditMode = System.Windows.Forms.DataGridViewEditMode.EditProgrammatically
        Me.ViewManager.EnableHeadersVisualStyles = False
        Me.ViewManager.GridColor = System.Drawing.Color.FromArgb(CType(CType(63, Byte), Integer), CType(CType(63, Byte), Integer), CType(CType(70, Byte), Integer))
        Me.ViewManager.Location = New System.Drawing.Point(0, 0)
        Me.ViewManager.MultiSelect = False
        Me.ViewManager.Name = "ViewManager"
        Me.ViewManager.RowHeadersVisible = False
        Me.ViewManager.ScrollBars = System.Windows.Forms.ScrollBars.None
        Me.ViewManager.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.ViewManager.ShowCellToolTips = False
        Me.ViewManager.Size = New System.Drawing.Size(319, 307)
        Me.ViewManager.TabIndex = 9
        '
        'Column1
        '
        Me.Column1.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None
        Me.Column1.HeaderText = ""
        Me.Column1.Name = "Column1"
        Me.Column1.Width = 30
        '
        'Column2
        '
        Me.Column2.HeaderText = "         "
        Me.Column2.Name = "Column2"
        Me.Column2.Resizable = System.Windows.Forms.DataGridViewTriState.[True]
        Me.Column2.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        Me.Column2.Width = 39
        '
        'VisualStudioHorizontalScrollBar1
        '
        Me.VisualStudioHorizontalScrollBar1.AmountOfInnerLines = SpyNote_V6._4.SN.VisualStudioHorizontalScrollBar.__InnerLineCount.One
        Me.VisualStudioHorizontalScrollBar1.BackColor = System.Drawing.Color.FromArgb(CType(CType(30, Byte), Integer), CType(CType(30, Byte), Integer), CType(CType(30, Byte), Integer))
        Me.VisualStudioHorizontalScrollBar1.BaseColour = System.Drawing.Color.FromArgb(CType(CType(45, Byte), Integer), CType(CType(45, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.VisualStudioHorizontalScrollBar1.ButtonSize = 16
        Me.VisualStudioHorizontalScrollBar1.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.VisualStudioHorizontalScrollBar1.LargeChange = 10
        Me.VisualStudioHorizontalScrollBar1.Location = New System.Drawing.Point(0, 307)
        Me.VisualStudioHorizontalScrollBar1.Maximum = 1
        Me.VisualStudioHorizontalScrollBar1.Minimum = 0
        Me.VisualStudioHorizontalScrollBar1.Name = "VisualStudioHorizontalScrollBar1"
        Me.VisualStudioHorizontalScrollBar1.OuterBorderColour = System.Drawing.Color.Empty
        Me.VisualStudioHorizontalScrollBar1.ShowOuterBorder = False
        Me.VisualStudioHorizontalScrollBar1.ShowThumbBorder = False
        Me.VisualStudioHorizontalScrollBar1.Size = New System.Drawing.Size(319, 10)
        Me.VisualStudioHorizontalScrollBar1.SmallChange = 10
        Me.VisualStudioHorizontalScrollBar1.TabIndex = 8
        Me.VisualStudioHorizontalScrollBar1.Text = "VisualStudioHorizontalScrollBar1"
        Me.VisualStudioHorizontalScrollBar1.ThumbBorderColour = System.Drawing.Color.Empty
        Me.VisualStudioHorizontalScrollBar1.ThumbHoverColour = System.Drawing.Color.FromArgb(CType(CType(140, Byte), Integer), CType(CType(140, Byte), Integer), CType(CType(143, Byte), Integer))
        Me.VisualStudioHorizontalScrollBar1.ThumbNormalColour = System.Drawing.Color.FromArgb(CType(CType(100, Byte), Integer), CType(CType(100, Byte), Integer), CType(CType(103, Byte), Integer))
        Me.VisualStudioHorizontalScrollBar1.ThumbPressedColour = System.Drawing.Color.FromArgb(CType(CType(200, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(203, Byte), Integer))
        Me.VisualStudioHorizontalScrollBar1.Value = 0
        '
        'VisualStudioVerticalScrollBar1
        '
        Me.VisualStudioVerticalScrollBar1.AmountOfInnerLines = SpyNote_V6._4.SN.VisualStudioVerticalScrollBar.__InnerLineCount.One
        Me.VisualStudioVerticalScrollBar1.BackColor = System.Drawing.Color.FromArgb(CType(CType(45, Byte), Integer), CType(CType(45, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.VisualStudioVerticalScrollBar1.BaseColour = System.Drawing.Color.FromArgb(CType(CType(45, Byte), Integer), CType(CType(45, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.VisualStudioVerticalScrollBar1.ButtonSize = 16
        Me.VisualStudioVerticalScrollBar1.Dock = System.Windows.Forms.DockStyle.Right
        Me.VisualStudioVerticalScrollBar1.LargeChange = 10
        Me.VisualStudioVerticalScrollBar1.LenColour = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(146, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.VisualStudioVerticalScrollBar1.Llen = -1
        Me.VisualStudioVerticalScrollBar1.Location = New System.Drawing.Point(319, 0)
        Me.VisualStudioVerticalScrollBar1.Maximum = 1
        Me.VisualStudioVerticalScrollBar1.Minimum = 0
        Me.VisualStudioVerticalScrollBar1.Name = "VisualStudioVerticalScrollBar1"
        Me.VisualStudioVerticalScrollBar1.OuterBorderColour = System.Drawing.Color.Empty
        Me.VisualStudioVerticalScrollBar1.ShowOuterBorder = False
        Me.VisualStudioVerticalScrollBar1.ShowThumbBorder = False
        Me.VisualStudioVerticalScrollBar1.Size = New System.Drawing.Size(10, 317)
        Me.VisualStudioVerticalScrollBar1.SmallChange = 10
        Me.VisualStudioVerticalScrollBar1.TabIndex = 7
        Me.VisualStudioVerticalScrollBar1.Text = "VisualStudioVerticalScrollBar1"
        Me.VisualStudioVerticalScrollBar1.ThumbBorderColour = System.Drawing.Color.Empty
        Me.VisualStudioVerticalScrollBar1.ThumbHoverColour = System.Drawing.Color.FromArgb(CType(CType(140, Byte), Integer), CType(CType(140, Byte), Integer), CType(CType(143, Byte), Integer))
        Me.VisualStudioVerticalScrollBar1.ThumbNormalColour = System.Drawing.Color.FromArgb(CType(CType(100, Byte), Integer), CType(CType(100, Byte), Integer), CType(CType(103, Byte), Integer))
        Me.VisualStudioVerticalScrollBar1.ThumbPressedColour = System.Drawing.Color.FromArgb(CType(CType(200, Byte), Integer), CType(CType(200, Byte), Integer), CType(CType(203, Byte), Integer))
        Me.VisualStudioVerticalScrollBar1.Value = 0
        '
        'TabPage2
        '
        Me.TabPage2.BackColor = System.Drawing.Color.FromArgb(CType(CType(45, Byte), Integer), CType(CType(45, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.TabPage2.Controls.Add(Me.PanelSystem)
        Me.TabPage2.Controls.Add(Me.PanelNotification)
        Me.TabPage2.Controls.Add(Me.PanelMedia)
        Me.TabPage2.Controls.Add(Me.PanelRingtone)
        Me.TabPage2.Location = New System.Drawing.Point(4, 54)
        Me.TabPage2.Name = "TabPage2"
        Me.TabPage2.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage2.Size = New System.Drawing.Size(335, 323)
        Me.TabPage2.TabIndex = 1
        Me.TabPage2.Text = "Votes and alerts"
        '
        'PanelSystem
        '
        Me.PanelSystem.Controls.Add(Me.ThemeSeparator3)
        Me.PanelSystem.Controls.Add(Me.TrackSystem)
        Me.PanelSystem.Controls.Add(Me.LabelSystem)
        Me.PanelSystem.Dock = System.Windows.Forms.DockStyle.Top
        Me.PanelSystem.Location = New System.Drawing.Point(3, 183)
        Me.PanelSystem.Name = "PanelSystem"
        Me.PanelSystem.Size = New System.Drawing.Size(329, 60)
        Me.PanelSystem.TabIndex = 3
        '
        'ThemeSeparator3
        '
        Me.ThemeSeparator3.Colour0 = System.Drawing.Color.FromArgb(CType(CType(33, Byte), Integer), CType(CType(33, Byte), Integer), CType(CType(40, Byte), Integer))
        Me.ThemeSeparator3.Colour1 = System.Drawing.Color.FromArgb(CType(CType(63, Byte), Integer), CType(CType(63, Byte), Integer), CType(CType(70, Byte), Integer))
        Me.ThemeSeparator3.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.ThemeSeparator3.Location = New System.Drawing.Point(0, 52)
        Me.ThemeSeparator3.Name = "ThemeSeparator3"
        Me.ThemeSeparator3.Size = New System.Drawing.Size(329, 8)
        Me.ThemeSeparator3.TabIndex = 21
        Me.ThemeSeparator3.Text = "ThemeSeparator1"
        '
        'TrackSystem
        '
        Me.TrackSystem.BackColor = System.Drawing.Color.FromArgb(CType(CType(37, Byte), Integer), CType(CType(37, Byte), Integer), CType(CType(38, Byte), Integer))
        Me.TrackSystem.Dock = System.Windows.Forms.DockStyle.Top
        Me.TrackSystem.DrawValueString = False
        Me.TrackSystem.JumpToMouse = False
        Me.TrackSystem.Location = New System.Drawing.Point(0, 15)
        Me.TrackSystem.Maximum = 10
        Me.TrackSystem.Minimum = 0
        Me.TrackSystem.MinimumSize = New System.Drawing.Size(47, 22)
        Me.TrackSystem.Name = "TrackSystem"
        Me.TrackSystem.Size = New System.Drawing.Size(329, 35)
        Me.TrackSystem.TabIndex = 20
        Me.TrackSystem.Text = "Track1"
        Me.TrackSystem.Value = 0
        Me.TrackSystem.ValueDivison = SpyNote_V6._4.SN.Track.ValueDivisor.By1
        Me.TrackSystem.ValueToSet = 0!
        '
        'LabelSystem
        '
        Me.LabelSystem.AutoSize = True
        Me.LabelSystem.Dock = System.Windows.Forms.DockStyle.Top
        Me.LabelSystem.Font = New System.Drawing.Font("Segoe UI Semibold", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LabelSystem.ForeColor = System.Drawing.Color.FromArgb(CType(CType(241, Byte), Integer), CType(CType(241, Byte), Integer), CType(CType(241, Byte), Integer))
        Me.LabelSystem.Location = New System.Drawing.Point(0, 0)
        Me.LabelSystem.Name = "LabelSystem"
        Me.LabelSystem.Size = New System.Drawing.Size(46, 15)
        Me.LabelSystem.TabIndex = 14
        Me.LabelSystem.Text = "System"
        '
        'PanelNotification
        '
        Me.PanelNotification.Controls.Add(Me.ThemeSeparator2)
        Me.PanelNotification.Controls.Add(Me.TrackNotification)
        Me.PanelNotification.Controls.Add(Me.LabelNotification)
        Me.PanelNotification.Dock = System.Windows.Forms.DockStyle.Top
        Me.PanelNotification.Location = New System.Drawing.Point(3, 123)
        Me.PanelNotification.Name = "PanelNotification"
        Me.PanelNotification.Size = New System.Drawing.Size(329, 60)
        Me.PanelNotification.TabIndex = 2
        '
        'ThemeSeparator2
        '
        Me.ThemeSeparator2.Colour0 = System.Drawing.Color.FromArgb(CType(CType(33, Byte), Integer), CType(CType(33, Byte), Integer), CType(CType(40, Byte), Integer))
        Me.ThemeSeparator2.Colour1 = System.Drawing.Color.FromArgb(CType(CType(63, Byte), Integer), CType(CType(63, Byte), Integer), CType(CType(70, Byte), Integer))
        Me.ThemeSeparator2.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.ThemeSeparator2.Location = New System.Drawing.Point(0, 52)
        Me.ThemeSeparator2.Name = "ThemeSeparator2"
        Me.ThemeSeparator2.Size = New System.Drawing.Size(329, 8)
        Me.ThemeSeparator2.TabIndex = 21
        Me.ThemeSeparator2.Text = "ThemeSeparator1"
        '
        'TrackNotification
        '
        Me.TrackNotification.BackColor = System.Drawing.Color.FromArgb(CType(CType(37, Byte), Integer), CType(CType(37, Byte), Integer), CType(CType(38, Byte), Integer))
        Me.TrackNotification.Dock = System.Windows.Forms.DockStyle.Top
        Me.TrackNotification.DrawValueString = False
        Me.TrackNotification.JumpToMouse = False
        Me.TrackNotification.Location = New System.Drawing.Point(0, 15)
        Me.TrackNotification.Maximum = 10
        Me.TrackNotification.Minimum = 0
        Me.TrackNotification.MinimumSize = New System.Drawing.Size(47, 22)
        Me.TrackNotification.Name = "TrackNotification"
        Me.TrackNotification.Size = New System.Drawing.Size(329, 35)
        Me.TrackNotification.TabIndex = 20
        Me.TrackNotification.Text = "Track1"
        Me.TrackNotification.Value = 0
        Me.TrackNotification.ValueDivison = SpyNote_V6._4.SN.Track.ValueDivisor.By1
        Me.TrackNotification.ValueToSet = 0!
        '
        'LabelNotification
        '
        Me.LabelNotification.AutoSize = True
        Me.LabelNotification.Dock = System.Windows.Forms.DockStyle.Top
        Me.LabelNotification.Font = New System.Drawing.Font("Segoe UI Semibold", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LabelNotification.ForeColor = System.Drawing.Color.FromArgb(CType(CType(241, Byte), Integer), CType(CType(241, Byte), Integer), CType(CType(241, Byte), Integer))
        Me.LabelNotification.Location = New System.Drawing.Point(0, 0)
        Me.LabelNotification.Name = "LabelNotification"
        Me.LabelNotification.Size = New System.Drawing.Size(70, 15)
        Me.LabelNotification.TabIndex = 14
        Me.LabelNotification.Text = "Notification"
        '
        'PanelMedia
        '
        Me.PanelMedia.Controls.Add(Me.ThemeSeparator1)
        Me.PanelMedia.Controls.Add(Me.TrackMedia)
        Me.PanelMedia.Controls.Add(Me.LabelMedia)
        Me.PanelMedia.Dock = System.Windows.Forms.DockStyle.Top
        Me.PanelMedia.Location = New System.Drawing.Point(3, 63)
        Me.PanelMedia.Name = "PanelMedia"
        Me.PanelMedia.Size = New System.Drawing.Size(329, 60)
        Me.PanelMedia.TabIndex = 1
        '
        'ThemeSeparator1
        '
        Me.ThemeSeparator1.Colour0 = System.Drawing.Color.FromArgb(CType(CType(33, Byte), Integer), CType(CType(33, Byte), Integer), CType(CType(40, Byte), Integer))
        Me.ThemeSeparator1.Colour1 = System.Drawing.Color.FromArgb(CType(CType(63, Byte), Integer), CType(CType(63, Byte), Integer), CType(CType(70, Byte), Integer))
        Me.ThemeSeparator1.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.ThemeSeparator1.Location = New System.Drawing.Point(0, 52)
        Me.ThemeSeparator1.Name = "ThemeSeparator1"
        Me.ThemeSeparator1.Size = New System.Drawing.Size(329, 8)
        Me.ThemeSeparator1.TabIndex = 22
        Me.ThemeSeparator1.Text = "ThemeSeparator1"
        '
        'TrackMedia
        '
        Me.TrackMedia.BackColor = System.Drawing.Color.FromArgb(CType(CType(37, Byte), Integer), CType(CType(37, Byte), Integer), CType(CType(38, Byte), Integer))
        Me.TrackMedia.Dock = System.Windows.Forms.DockStyle.Top
        Me.TrackMedia.DrawValueString = False
        Me.TrackMedia.JumpToMouse = False
        Me.TrackMedia.Location = New System.Drawing.Point(0, 15)
        Me.TrackMedia.Maximum = 10
        Me.TrackMedia.Minimum = 0
        Me.TrackMedia.MinimumSize = New System.Drawing.Size(47, 22)
        Me.TrackMedia.Name = "TrackMedia"
        Me.TrackMedia.Size = New System.Drawing.Size(329, 35)
        Me.TrackMedia.TabIndex = 21
        Me.TrackMedia.Text = "Track1"
        Me.TrackMedia.Value = 0
        Me.TrackMedia.ValueDivison = SpyNote_V6._4.SN.Track.ValueDivisor.By1
        Me.TrackMedia.ValueToSet = 0!
        '
        'LabelMedia
        '
        Me.LabelMedia.AutoSize = True
        Me.LabelMedia.Dock = System.Windows.Forms.DockStyle.Top
        Me.LabelMedia.Font = New System.Drawing.Font("Segoe UI Semibold", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LabelMedia.ForeColor = System.Drawing.Color.FromArgb(CType(CType(241, Byte), Integer), CType(CType(241, Byte), Integer), CType(CType(241, Byte), Integer))
        Me.LabelMedia.Location = New System.Drawing.Point(0, 0)
        Me.LabelMedia.Name = "LabelMedia"
        Me.LabelMedia.Size = New System.Drawing.Size(40, 15)
        Me.LabelMedia.TabIndex = 15
        Me.LabelMedia.Text = "Media"
        '
        'PanelRingtone
        '
        Me.PanelRingtone.Controls.Add(Me.TSEP1)
        Me.PanelRingtone.Controls.Add(Me.TrackRingtone)
        Me.PanelRingtone.Controls.Add(Me.LabelRingtone)
        Me.PanelRingtone.Dock = System.Windows.Forms.DockStyle.Top
        Me.PanelRingtone.Location = New System.Drawing.Point(3, 3)
        Me.PanelRingtone.Name = "PanelRingtone"
        Me.PanelRingtone.Size = New System.Drawing.Size(329, 60)
        Me.PanelRingtone.TabIndex = 0
        '
        'TSEP1
        '
        Me.TSEP1.Colour0 = System.Drawing.Color.FromArgb(CType(CType(33, Byte), Integer), CType(CType(33, Byte), Integer), CType(CType(40, Byte), Integer))
        Me.TSEP1.Colour1 = System.Drawing.Color.FromArgb(CType(CType(63, Byte), Integer), CType(CType(63, Byte), Integer), CType(CType(70, Byte), Integer))
        Me.TSEP1.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.TSEP1.Location = New System.Drawing.Point(0, 52)
        Me.TSEP1.Name = "TSEP1"
        Me.TSEP1.Size = New System.Drawing.Size(329, 8)
        Me.TSEP1.TabIndex = 21
        Me.TSEP1.Text = "ThemeSeparator1"
        '
        'TrackRingtone
        '
        Me.TrackRingtone.BackColor = System.Drawing.Color.FromArgb(CType(CType(37, Byte), Integer), CType(CType(37, Byte), Integer), CType(CType(38, Byte), Integer))
        Me.TrackRingtone.Dock = System.Windows.Forms.DockStyle.Top
        Me.TrackRingtone.DrawValueString = False
        Me.TrackRingtone.JumpToMouse = False
        Me.TrackRingtone.Location = New System.Drawing.Point(0, 15)
        Me.TrackRingtone.Maximum = 10
        Me.TrackRingtone.Minimum = 0
        Me.TrackRingtone.MinimumSize = New System.Drawing.Size(47, 22)
        Me.TrackRingtone.Name = "TrackRingtone"
        Me.TrackRingtone.Size = New System.Drawing.Size(329, 35)
        Me.TrackRingtone.TabIndex = 20
        Me.TrackRingtone.Text = "Track1"
        Me.TrackRingtone.Value = 0
        Me.TrackRingtone.ValueDivison = SpyNote_V6._4.SN.Track.ValueDivisor.By1
        Me.TrackRingtone.ValueToSet = 0!
        '
        'LabelRingtone
        '
        Me.LabelRingtone.AutoSize = True
        Me.LabelRingtone.Dock = System.Windows.Forms.DockStyle.Top
        Me.LabelRingtone.Font = New System.Drawing.Font("Segoe UI Semibold", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LabelRingtone.ForeColor = System.Drawing.Color.FromArgb(CType(CType(241, Byte), Integer), CType(CType(241, Byte), Integer), CType(CType(241, Byte), Integer))
        Me.LabelRingtone.Location = New System.Drawing.Point(0, 0)
        Me.LabelRingtone.Name = "LabelRingtone"
        Me.LabelRingtone.Size = New System.Drawing.Size(55, 15)
        Me.LabelRingtone.TabIndex = 14
        Me.LabelRingtone.Text = "Ringtone"
        '
        'TabPage3
        '
        Me.TabPage3.BackColor = System.Drawing.Color.FromArgb(CType(CType(37, Byte), Integer), CType(CType(37, Byte), Integer), CType(CType(38, Byte), Integer))
        Me.TabPage3.Controls.Add(Me.PanelBar)
        Me.TabPage3.Location = New System.Drawing.Point(4, 54)
        Me.TabPage3.Name = "TabPage3"
        Me.TabPage3.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage3.Size = New System.Drawing.Size(335, 323)
        Me.TabPage3.TabIndex = 2
        Me.TabPage3.Text = "Phone bar"
        '
        'PanelBar
        '
        Me.PanelBar.BackColor = System.Drawing.Color.FromArgb(CType(CType(45, Byte), Integer), CType(CType(45, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.PanelBar.Controls.Add(Me.ThemeSeparator5)
        Me.PanelBar.Controls.Add(Me.ThemeSeparator4)
        Me.PanelBar.Controls.Add(Me.LabBarWifirest)
        Me.PanelBar.Controls.Add(Me.LabBarWifiDisconnect)
        Me.PanelBar.Controls.Add(Me.LabBarWifiConnected)
        Me.PanelBar.Controls.Add(Me.LabBarMobileData)
        Me.PanelBar.Controls.Add(Me.LabBarGps)
        Me.PanelBar.Controls.Add(Me.LabBarBluetooth)
        Me.PanelBar.Controls.Add(Me.LabBarSilent)
        Me.PanelBar.Controls.Add(Me.LabBarVibrate)
        Me.PanelBar.Controls.Add(Me.LabBarNormal)
        Me.PanelBar.Controls.Add(Me.BtnBarWifirest)
        Me.PanelBar.Controls.Add(Me.BtnBarWifiDisconnect)
        Me.PanelBar.Controls.Add(Me.BtnBarWifiConnected)
        Me.PanelBar.Controls.Add(Me.BtnBarMobileData)
        Me.PanelBar.Controls.Add(Me.BtnBarGps)
        Me.PanelBar.Controls.Add(Me.BtnBarBluetooth)
        Me.PanelBar.Controls.Add(Me.BtnBarSilent)
        Me.PanelBar.Controls.Add(Me.BtnBarVibrate)
        Me.PanelBar.Controls.Add(Me.BtnBarNormal)
        Me.PanelBar.Dock = System.Windows.Forms.DockStyle.Fill
        Me.PanelBar.Location = New System.Drawing.Point(3, 3)
        Me.PanelBar.Name = "PanelBar"
        Me.PanelBar.Size = New System.Drawing.Size(329, 317)
        Me.PanelBar.TabIndex = 0
        '
        'ThemeSeparator5
        '
        Me.ThemeSeparator5.Colour0 = System.Drawing.Color.FromArgb(CType(CType(33, Byte), Integer), CType(CType(33, Byte), Integer), CType(CType(40, Byte), Integer))
        Me.ThemeSeparator5.Colour1 = System.Drawing.Color.FromArgb(CType(CType(63, Byte), Integer), CType(CType(63, Byte), Integer), CType(CType(70, Byte), Integer))
        Me.ThemeSeparator5.Location = New System.Drawing.Point(26, 202)
        Me.ThemeSeparator5.Name = "ThemeSeparator5"
        Me.ThemeSeparator5.Size = New System.Drawing.Size(264, 10)
        Me.ThemeSeparator5.TabIndex = 28
        Me.ThemeSeparator5.Text = "ThemeSeparator5"
        '
        'ThemeSeparator4
        '
        Me.ThemeSeparator4.Colour0 = System.Drawing.Color.FromArgb(CType(CType(33, Byte), Integer), CType(CType(33, Byte), Integer), CType(CType(40, Byte), Integer))
        Me.ThemeSeparator4.Colour1 = System.Drawing.Color.FromArgb(CType(CType(63, Byte), Integer), CType(CType(63, Byte), Integer), CType(CType(70, Byte), Integer))
        Me.ThemeSeparator4.Location = New System.Drawing.Point(26, 99)
        Me.ThemeSeparator4.Name = "ThemeSeparator4"
        Me.ThemeSeparator4.Size = New System.Drawing.Size(264, 10)
        Me.ThemeSeparator4.TabIndex = 27
        Me.ThemeSeparator4.Text = "ThemeSeparator4"
        '
        'LabBarWifirest
        '
        Me.LabBarWifirest.AutoSize = True
        Me.LabBarWifirest.Font = New System.Drawing.Font("Segoe UI Semibold", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LabBarWifirest.ForeColor = System.Drawing.Color.FromArgb(CType(CType(241, Byte), Integer), CType(CType(241, Byte), Integer), CType(CType(241, Byte), Integer))
        Me.LabBarWifirest.Location = New System.Drawing.Point(238, 287)
        Me.LabBarWifirest.Name = "LabBarWifirest"
        Me.LabBarWifirest.Size = New System.Drawing.Size(51, 15)
        Me.LabBarWifirest.TabIndex = 26
        Me.LabBarWifirest.Text = "Wifi rest"
        '
        'LabBarWifiDisconnect
        '
        Me.LabBarWifiDisconnect.AutoSize = True
        Me.LabBarWifiDisconnect.Font = New System.Drawing.Font("Segoe UI Semibold", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LabBarWifiDisconnect.ForeColor = System.Drawing.Color.FromArgb(CType(CType(241, Byte), Integer), CType(CType(241, Byte), Integer), CType(CType(241, Byte), Integer))
        Me.LabBarWifiDisconnect.Location = New System.Drawing.Point(115, 287)
        Me.LabBarWifiDisconnect.Name = "LabBarWifiDisconnect"
        Me.LabBarWifiDisconnect.Size = New System.Drawing.Size(88, 15)
        Me.LabBarWifiDisconnect.TabIndex = 25
        Me.LabBarWifiDisconnect.Text = "Wifi Disconnec"
        '
        'LabBarWifiConnected
        '
        Me.LabBarWifiConnected.AutoSize = True
        Me.LabBarWifiConnected.Font = New System.Drawing.Font("Segoe UI Semibold", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LabBarWifiConnected.ForeColor = System.Drawing.Color.FromArgb(CType(CType(241, Byte), Integer), CType(CType(241, Byte), Integer), CType(CType(241, Byte), Integer))
        Me.LabBarWifiConnected.Location = New System.Drawing.Point(11, 287)
        Me.LabBarWifiConnected.Name = "LabBarWifiConnected"
        Me.LabBarWifiConnected.Size = New System.Drawing.Size(89, 15)
        Me.LabBarWifiConnected.TabIndex = 24
        Me.LabBarWifiConnected.Text = "Wifi Connected"
        '
        'LabBarMobileData
        '
        Me.LabBarMobileData.AutoSize = True
        Me.LabBarMobileData.Font = New System.Drawing.Font("Segoe UI Semibold", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LabBarMobileData.ForeColor = System.Drawing.Color.FromArgb(CType(CType(241, Byte), Integer), CType(CType(241, Byte), Integer), CType(CType(241, Byte), Integer))
        Me.LabBarMobileData.Location = New System.Drawing.Point(232, 183)
        Me.LabBarMobileData.Name = "LabBarMobileData"
        Me.LabBarMobileData.Size = New System.Drawing.Size(72, 15)
        Me.LabBarMobileData.TabIndex = 23
        Me.LabBarMobileData.Text = "Mobile Data"
        '
        'LabBarGps
        '
        Me.LabBarGps.AutoSize = True
        Me.LabBarGps.Font = New System.Drawing.Font("Segoe UI Semibold", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LabBarGps.ForeColor = System.Drawing.Color.FromArgb(CType(CType(241, Byte), Integer), CType(CType(241, Byte), Integer), CType(CType(241, Byte), Integer))
        Me.LabBarGps.Location = New System.Drawing.Point(142, 183)
        Me.LabBarGps.Name = "LabBarGps"
        Me.LabBarGps.Size = New System.Drawing.Size(27, 15)
        Me.LabBarGps.TabIndex = 22
        Me.LabBarGps.Text = "Gps"
        '
        'LabBarBluetooth
        '
        Me.LabBarBluetooth.AutoSize = True
        Me.LabBarBluetooth.Font = New System.Drawing.Font("Segoe UI Semibold", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LabBarBluetooth.ForeColor = System.Drawing.Color.FromArgb(CType(CType(241, Byte), Integer), CType(CType(241, Byte), Integer), CType(CType(241, Byte), Integer))
        Me.LabBarBluetooth.Location = New System.Drawing.Point(28, 183)
        Me.LabBarBluetooth.Name = "LabBarBluetooth"
        Me.LabBarBluetooth.Size = New System.Drawing.Size(59, 15)
        Me.LabBarBluetooth.TabIndex = 21
        Me.LabBarBluetooth.Text = "Bluetooth"
        '
        'LabBarSilent
        '
        Me.LabBarSilent.AutoSize = True
        Me.LabBarSilent.Font = New System.Drawing.Font("Segoe UI Semibold", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LabBarSilent.ForeColor = System.Drawing.Color.FromArgb(CType(CType(241, Byte), Integer), CType(CType(241, Byte), Integer), CType(CType(241, Byte), Integer))
        Me.LabBarSilent.Location = New System.Drawing.Point(244, 81)
        Me.LabBarSilent.Name = "LabBarSilent"
        Me.LabBarSilent.Size = New System.Drawing.Size(37, 15)
        Me.LabBarSilent.TabIndex = 20
        Me.LabBarSilent.Text = "Silent"
        '
        'LabBarVibrate
        '
        Me.LabBarVibrate.AutoSize = True
        Me.LabBarVibrate.Font = New System.Drawing.Font("Segoe UI Semibold", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LabBarVibrate.ForeColor = System.Drawing.Color.FromArgb(CType(CType(241, Byte), Integer), CType(CType(241, Byte), Integer), CType(CType(241, Byte), Integer))
        Me.LabBarVibrate.Location = New System.Drawing.Point(133, 81)
        Me.LabBarVibrate.Name = "LabBarVibrate"
        Me.LabBarVibrate.Size = New System.Drawing.Size(45, 15)
        Me.LabBarVibrate.TabIndex = 19
        Me.LabBarVibrate.Text = "Vibrate"
        '
        'LabBarNormal
        '
        Me.LabBarNormal.AutoSize = True
        Me.LabBarNormal.Font = New System.Drawing.Font("Segoe UI Semibold", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LabBarNormal.ForeColor = System.Drawing.Color.FromArgb(CType(CType(241, Byte), Integer), CType(CType(241, Byte), Integer), CType(CType(241, Byte), Integer))
        Me.LabBarNormal.Location = New System.Drawing.Point(28, 81)
        Me.LabBarNormal.Name = "LabBarNormal"
        Me.LabBarNormal.Size = New System.Drawing.Size(47, 15)
        Me.LabBarNormal.TabIndex = 18
        Me.LabBarNormal.Text = "Normal"
        '
        'BtnBarWifirest
        '
        Me.BtnBarWifirest.CLRDown0 = System.Drawing.Color.FromArgb(CType(CType(37, Byte), Integer), CType(CType(37, Byte), Integer), CType(CType(38, Byte), Integer))
        Me.BtnBarWifirest.CLRDown1 = System.Drawing.Color.FromArgb(CType(CType(37, Byte), Integer), CType(CType(37, Byte), Integer), CType(CType(38, Byte), Integer))
        Me.BtnBarWifirest.CLRDownbrd = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(146, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.BtnBarWifirest.CLREnabled = System.Drawing.Color.FromArgb(CType(CType(31, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(32, Byte), Integer))
        Me.BtnBarWifirest.CLRNone0 = System.Drawing.Color.FromArgb(CType(CType(37, Byte), Integer), CType(CType(37, Byte), Integer), CType(CType(38, Byte), Integer))
        Me.BtnBarWifirest.CLRNone1 = System.Drawing.Color.FromArgb(CType(CType(37, Byte), Integer), CType(CType(37, Byte), Integer), CType(CType(38, Byte), Integer))
        Me.BtnBarWifirest.CLRNonebrd = System.Drawing.Color.FromArgb(CType(CType(85, Byte), Integer), CType(CType(85, Byte), Integer), CType(CType(85, Byte), Integer))
        Me.BtnBarWifirest.CLROver0 = System.Drawing.Color.FromArgb(CType(CType(45, Byte), Integer), CType(CType(45, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.BtnBarWifirest.CLROver1 = System.Drawing.Color.FromArgb(CType(CType(45, Byte), Integer), CType(CType(45, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.BtnBarWifirest.CLROverbrd = System.Drawing.Color.FromArgb(CType(CType(85, Byte), Integer), CType(CType(85, Byte), Integer), CType(CType(85, Byte), Integer))
        Me.BtnBarWifirest.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Bold)
        Me.BtnBarWifirest.ImageChoice = Nothing
        Me.BtnBarWifirest.Location = New System.Drawing.Point(230, 218)
        Me.BtnBarWifirest.Name = "BtnBarWifirest"
        Me.BtnBarWifirest.ShowImage = False
        Me.BtnBarWifirest.Size = New System.Drawing.Size(65, 65)
        Me.BtnBarWifirest.TabIndex = 11
        Me.BtnBarWifirest.Text = "ThemeBtnBar1"
        '
        'BtnBarWifiDisconnect
        '
        Me.BtnBarWifiDisconnect.CLRDown0 = System.Drawing.Color.FromArgb(CType(CType(37, Byte), Integer), CType(CType(37, Byte), Integer), CType(CType(38, Byte), Integer))
        Me.BtnBarWifiDisconnect.CLRDown1 = System.Drawing.Color.FromArgb(CType(CType(37, Byte), Integer), CType(CType(37, Byte), Integer), CType(CType(38, Byte), Integer))
        Me.BtnBarWifiDisconnect.CLRDownbrd = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(146, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.BtnBarWifiDisconnect.CLREnabled = System.Drawing.Color.FromArgb(CType(CType(31, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(32, Byte), Integer))
        Me.BtnBarWifiDisconnect.CLRNone0 = System.Drawing.Color.FromArgb(CType(CType(37, Byte), Integer), CType(CType(37, Byte), Integer), CType(CType(38, Byte), Integer))
        Me.BtnBarWifiDisconnect.CLRNone1 = System.Drawing.Color.FromArgb(CType(CType(37, Byte), Integer), CType(CType(37, Byte), Integer), CType(CType(38, Byte), Integer))
        Me.BtnBarWifiDisconnect.CLRNonebrd = System.Drawing.Color.FromArgb(CType(CType(85, Byte), Integer), CType(CType(85, Byte), Integer), CType(CType(85, Byte), Integer))
        Me.BtnBarWifiDisconnect.CLROver0 = System.Drawing.Color.FromArgb(CType(CType(45, Byte), Integer), CType(CType(45, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.BtnBarWifiDisconnect.CLROver1 = System.Drawing.Color.FromArgb(CType(CType(45, Byte), Integer), CType(CType(45, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.BtnBarWifiDisconnect.CLROverbrd = System.Drawing.Color.FromArgb(CType(CType(85, Byte), Integer), CType(CType(85, Byte), Integer), CType(CType(85, Byte), Integer))
        Me.BtnBarWifiDisconnect.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Bold)
        Me.BtnBarWifiDisconnect.ImageChoice = Nothing
        Me.BtnBarWifiDisconnect.Location = New System.Drawing.Point(123, 218)
        Me.BtnBarWifiDisconnect.Name = "BtnBarWifiDisconnect"
        Me.BtnBarWifiDisconnect.ShowImage = False
        Me.BtnBarWifiDisconnect.Size = New System.Drawing.Size(65, 65)
        Me.BtnBarWifiDisconnect.TabIndex = 10
        Me.BtnBarWifiDisconnect.Text = "ThemeBtnBar1"
        '
        'BtnBarWifiConnected
        '
        Me.BtnBarWifiConnected.CLRDown0 = System.Drawing.Color.FromArgb(CType(CType(37, Byte), Integer), CType(CType(37, Byte), Integer), CType(CType(38, Byte), Integer))
        Me.BtnBarWifiConnected.CLRDown1 = System.Drawing.Color.FromArgb(CType(CType(37, Byte), Integer), CType(CType(37, Byte), Integer), CType(CType(38, Byte), Integer))
        Me.BtnBarWifiConnected.CLRDownbrd = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(146, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.BtnBarWifiConnected.CLREnabled = System.Drawing.Color.FromArgb(CType(CType(31, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(32, Byte), Integer))
        Me.BtnBarWifiConnected.CLRNone0 = System.Drawing.Color.FromArgb(CType(CType(37, Byte), Integer), CType(CType(37, Byte), Integer), CType(CType(38, Byte), Integer))
        Me.BtnBarWifiConnected.CLRNone1 = System.Drawing.Color.FromArgb(CType(CType(37, Byte), Integer), CType(CType(37, Byte), Integer), CType(CType(38, Byte), Integer))
        Me.BtnBarWifiConnected.CLRNonebrd = System.Drawing.Color.FromArgb(CType(CType(85, Byte), Integer), CType(CType(85, Byte), Integer), CType(CType(85, Byte), Integer))
        Me.BtnBarWifiConnected.CLROver0 = System.Drawing.Color.FromArgb(CType(CType(45, Byte), Integer), CType(CType(45, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.BtnBarWifiConnected.CLROver1 = System.Drawing.Color.FromArgb(CType(CType(45, Byte), Integer), CType(CType(45, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.BtnBarWifiConnected.CLROverbrd = System.Drawing.Color.FromArgb(CType(CType(85, Byte), Integer), CType(CType(85, Byte), Integer), CType(CType(85, Byte), Integer))
        Me.BtnBarWifiConnected.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Bold)
        Me.BtnBarWifiConnected.ImageChoice = Nothing
        Me.BtnBarWifiConnected.Location = New System.Drawing.Point(18, 218)
        Me.BtnBarWifiConnected.Name = "BtnBarWifiConnected"
        Me.BtnBarWifiConnected.ShowImage = False
        Me.BtnBarWifiConnected.Size = New System.Drawing.Size(65, 65)
        Me.BtnBarWifiConnected.TabIndex = 9
        Me.BtnBarWifiConnected.Text = "ThemeBtnBar1"
        '
        'BtnBarMobileData
        '
        Me.BtnBarMobileData.CLRDown0 = System.Drawing.Color.FromArgb(CType(CType(37, Byte), Integer), CType(CType(37, Byte), Integer), CType(CType(38, Byte), Integer))
        Me.BtnBarMobileData.CLRDown1 = System.Drawing.Color.FromArgb(CType(CType(37, Byte), Integer), CType(CType(37, Byte), Integer), CType(CType(38, Byte), Integer))
        Me.BtnBarMobileData.CLRDownbrd = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(146, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.BtnBarMobileData.CLREnabled = System.Drawing.Color.FromArgb(CType(CType(31, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(32, Byte), Integer))
        Me.BtnBarMobileData.CLRNone0 = System.Drawing.Color.FromArgb(CType(CType(37, Byte), Integer), CType(CType(37, Byte), Integer), CType(CType(38, Byte), Integer))
        Me.BtnBarMobileData.CLRNone1 = System.Drawing.Color.FromArgb(CType(CType(37, Byte), Integer), CType(CType(37, Byte), Integer), CType(CType(38, Byte), Integer))
        Me.BtnBarMobileData.CLRNonebrd = System.Drawing.Color.FromArgb(CType(CType(85, Byte), Integer), CType(CType(85, Byte), Integer), CType(CType(85, Byte), Integer))
        Me.BtnBarMobileData.CLROver0 = System.Drawing.Color.FromArgb(CType(CType(45, Byte), Integer), CType(CType(45, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.BtnBarMobileData.CLROver1 = System.Drawing.Color.FromArgb(CType(CType(45, Byte), Integer), CType(CType(45, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.BtnBarMobileData.CLROverbrd = System.Drawing.Color.FromArgb(CType(CType(85, Byte), Integer), CType(CType(85, Byte), Integer), CType(CType(85, Byte), Integer))
        Me.BtnBarMobileData.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Bold)
        Me.BtnBarMobileData.ImageChoice = Nothing
        Me.BtnBarMobileData.Location = New System.Drawing.Point(230, 115)
        Me.BtnBarMobileData.Name = "BtnBarMobileData"
        Me.BtnBarMobileData.ShowImage = False
        Me.BtnBarMobileData.Size = New System.Drawing.Size(65, 65)
        Me.BtnBarMobileData.TabIndex = 8
        Me.BtnBarMobileData.Text = "ThemeBtnBar1"
        '
        'BtnBarGps
        '
        Me.BtnBarGps.CLRDown0 = System.Drawing.Color.FromArgb(CType(CType(37, Byte), Integer), CType(CType(37, Byte), Integer), CType(CType(38, Byte), Integer))
        Me.BtnBarGps.CLRDown1 = System.Drawing.Color.FromArgb(CType(CType(37, Byte), Integer), CType(CType(37, Byte), Integer), CType(CType(38, Byte), Integer))
        Me.BtnBarGps.CLRDownbrd = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(146, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.BtnBarGps.CLREnabled = System.Drawing.Color.FromArgb(CType(CType(31, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(32, Byte), Integer))
        Me.BtnBarGps.CLRNone0 = System.Drawing.Color.FromArgb(CType(CType(37, Byte), Integer), CType(CType(37, Byte), Integer), CType(CType(38, Byte), Integer))
        Me.BtnBarGps.CLRNone1 = System.Drawing.Color.FromArgb(CType(CType(37, Byte), Integer), CType(CType(37, Byte), Integer), CType(CType(38, Byte), Integer))
        Me.BtnBarGps.CLRNonebrd = System.Drawing.Color.FromArgb(CType(CType(85, Byte), Integer), CType(CType(85, Byte), Integer), CType(CType(85, Byte), Integer))
        Me.BtnBarGps.CLROver0 = System.Drawing.Color.FromArgb(CType(CType(45, Byte), Integer), CType(CType(45, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.BtnBarGps.CLROver1 = System.Drawing.Color.FromArgb(CType(CType(45, Byte), Integer), CType(CType(45, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.BtnBarGps.CLROverbrd = System.Drawing.Color.FromArgb(CType(CType(85, Byte), Integer), CType(CType(85, Byte), Integer), CType(CType(85, Byte), Integer))
        Me.BtnBarGps.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Bold)
        Me.BtnBarGps.ImageChoice = Nothing
        Me.BtnBarGps.Location = New System.Drawing.Point(123, 115)
        Me.BtnBarGps.Name = "BtnBarGps"
        Me.BtnBarGps.ShowImage = False
        Me.BtnBarGps.Size = New System.Drawing.Size(65, 65)
        Me.BtnBarGps.TabIndex = 7
        Me.BtnBarGps.Text = "ThemeBtnBar1"
        '
        'BtnBarBluetooth
        '
        Me.BtnBarBluetooth.CLRDown0 = System.Drawing.Color.FromArgb(CType(CType(37, Byte), Integer), CType(CType(37, Byte), Integer), CType(CType(38, Byte), Integer))
        Me.BtnBarBluetooth.CLRDown1 = System.Drawing.Color.FromArgb(CType(CType(37, Byte), Integer), CType(CType(37, Byte), Integer), CType(CType(38, Byte), Integer))
        Me.BtnBarBluetooth.CLRDownbrd = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(146, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.BtnBarBluetooth.CLREnabled = System.Drawing.Color.FromArgb(CType(CType(31, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(32, Byte), Integer))
        Me.BtnBarBluetooth.CLRNone0 = System.Drawing.Color.FromArgb(CType(CType(37, Byte), Integer), CType(CType(37, Byte), Integer), CType(CType(38, Byte), Integer))
        Me.BtnBarBluetooth.CLRNone1 = System.Drawing.Color.FromArgb(CType(CType(37, Byte), Integer), CType(CType(37, Byte), Integer), CType(CType(38, Byte), Integer))
        Me.BtnBarBluetooth.CLRNonebrd = System.Drawing.Color.FromArgb(CType(CType(85, Byte), Integer), CType(CType(85, Byte), Integer), CType(CType(85, Byte), Integer))
        Me.BtnBarBluetooth.CLROver0 = System.Drawing.Color.FromArgb(CType(CType(45, Byte), Integer), CType(CType(45, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.BtnBarBluetooth.CLROver1 = System.Drawing.Color.FromArgb(CType(CType(45, Byte), Integer), CType(CType(45, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.BtnBarBluetooth.CLROverbrd = System.Drawing.Color.FromArgb(CType(CType(85, Byte), Integer), CType(CType(85, Byte), Integer), CType(CType(85, Byte), Integer))
        Me.BtnBarBluetooth.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Bold)
        Me.BtnBarBluetooth.ImageChoice = Nothing
        Me.BtnBarBluetooth.Location = New System.Drawing.Point(18, 115)
        Me.BtnBarBluetooth.Name = "BtnBarBluetooth"
        Me.BtnBarBluetooth.ShowImage = False
        Me.BtnBarBluetooth.Size = New System.Drawing.Size(65, 65)
        Me.BtnBarBluetooth.TabIndex = 6
        Me.BtnBarBluetooth.Text = "ThemeBtnBar1"
        '
        'BtnBarSilent
        '
        Me.BtnBarSilent.CLRDown0 = System.Drawing.Color.FromArgb(CType(CType(37, Byte), Integer), CType(CType(37, Byte), Integer), CType(CType(38, Byte), Integer))
        Me.BtnBarSilent.CLRDown1 = System.Drawing.Color.FromArgb(CType(CType(37, Byte), Integer), CType(CType(37, Byte), Integer), CType(CType(38, Byte), Integer))
        Me.BtnBarSilent.CLRDownbrd = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(146, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.BtnBarSilent.CLREnabled = System.Drawing.Color.FromArgb(CType(CType(31, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(32, Byte), Integer))
        Me.BtnBarSilent.CLRNone0 = System.Drawing.Color.FromArgb(CType(CType(37, Byte), Integer), CType(CType(37, Byte), Integer), CType(CType(38, Byte), Integer))
        Me.BtnBarSilent.CLRNone1 = System.Drawing.Color.FromArgb(CType(CType(37, Byte), Integer), CType(CType(37, Byte), Integer), CType(CType(38, Byte), Integer))
        Me.BtnBarSilent.CLRNonebrd = System.Drawing.Color.FromArgb(CType(CType(85, Byte), Integer), CType(CType(85, Byte), Integer), CType(CType(85, Byte), Integer))
        Me.BtnBarSilent.CLROver0 = System.Drawing.Color.FromArgb(CType(CType(45, Byte), Integer), CType(CType(45, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.BtnBarSilent.CLROver1 = System.Drawing.Color.FromArgb(CType(CType(45, Byte), Integer), CType(CType(45, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.BtnBarSilent.CLROverbrd = System.Drawing.Color.FromArgb(CType(CType(85, Byte), Integer), CType(CType(85, Byte), Integer), CType(CType(85, Byte), Integer))
        Me.BtnBarSilent.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Bold)
        Me.BtnBarSilent.ImageChoice = Nothing
        Me.BtnBarSilent.Location = New System.Drawing.Point(230, 13)
        Me.BtnBarSilent.Name = "BtnBarSilent"
        Me.BtnBarSilent.ShowImage = False
        Me.BtnBarSilent.Size = New System.Drawing.Size(65, 65)
        Me.BtnBarSilent.TabIndex = 5
        Me.BtnBarSilent.Text = "ThemeBtnBar1"
        '
        'BtnBarVibrate
        '
        Me.BtnBarVibrate.CLRDown0 = System.Drawing.Color.FromArgb(CType(CType(37, Byte), Integer), CType(CType(37, Byte), Integer), CType(CType(38, Byte), Integer))
        Me.BtnBarVibrate.CLRDown1 = System.Drawing.Color.FromArgb(CType(CType(37, Byte), Integer), CType(CType(37, Byte), Integer), CType(CType(38, Byte), Integer))
        Me.BtnBarVibrate.CLRDownbrd = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(146, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.BtnBarVibrate.CLREnabled = System.Drawing.Color.FromArgb(CType(CType(31, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(32, Byte), Integer))
        Me.BtnBarVibrate.CLRNone0 = System.Drawing.Color.FromArgb(CType(CType(37, Byte), Integer), CType(CType(37, Byte), Integer), CType(CType(38, Byte), Integer))
        Me.BtnBarVibrate.CLRNone1 = System.Drawing.Color.FromArgb(CType(CType(37, Byte), Integer), CType(CType(37, Byte), Integer), CType(CType(38, Byte), Integer))
        Me.BtnBarVibrate.CLRNonebrd = System.Drawing.Color.FromArgb(CType(CType(85, Byte), Integer), CType(CType(85, Byte), Integer), CType(CType(85, Byte), Integer))
        Me.BtnBarVibrate.CLROver0 = System.Drawing.Color.FromArgb(CType(CType(45, Byte), Integer), CType(CType(45, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.BtnBarVibrate.CLROver1 = System.Drawing.Color.FromArgb(CType(CType(45, Byte), Integer), CType(CType(45, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.BtnBarVibrate.CLROverbrd = System.Drawing.Color.FromArgb(CType(CType(85, Byte), Integer), CType(CType(85, Byte), Integer), CType(CType(85, Byte), Integer))
        Me.BtnBarVibrate.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Bold)
        Me.BtnBarVibrate.ImageChoice = Nothing
        Me.BtnBarVibrate.Location = New System.Drawing.Point(123, 13)
        Me.BtnBarVibrate.Name = "BtnBarVibrate"
        Me.BtnBarVibrate.ShowImage = False
        Me.BtnBarVibrate.Size = New System.Drawing.Size(65, 65)
        Me.BtnBarVibrate.TabIndex = 4
        Me.BtnBarVibrate.Text = "ThemeBtnBar1"
        '
        'BtnBarNormal
        '
        Me.BtnBarNormal.CLRDown0 = System.Drawing.Color.FromArgb(CType(CType(37, Byte), Integer), CType(CType(37, Byte), Integer), CType(CType(38, Byte), Integer))
        Me.BtnBarNormal.CLRDown1 = System.Drawing.Color.FromArgb(CType(CType(37, Byte), Integer), CType(CType(37, Byte), Integer), CType(CType(38, Byte), Integer))
        Me.BtnBarNormal.CLRDownbrd = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(146, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.BtnBarNormal.CLREnabled = System.Drawing.Color.FromArgb(CType(CType(31, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(32, Byte), Integer))
        Me.BtnBarNormal.CLRNone0 = System.Drawing.Color.FromArgb(CType(CType(37, Byte), Integer), CType(CType(37, Byte), Integer), CType(CType(38, Byte), Integer))
        Me.BtnBarNormal.CLRNone1 = System.Drawing.Color.FromArgb(CType(CType(37, Byte), Integer), CType(CType(37, Byte), Integer), CType(CType(38, Byte), Integer))
        Me.BtnBarNormal.CLRNonebrd = System.Drawing.Color.FromArgb(CType(CType(85, Byte), Integer), CType(CType(85, Byte), Integer), CType(CType(85, Byte), Integer))
        Me.BtnBarNormal.CLROver0 = System.Drawing.Color.FromArgb(CType(CType(45, Byte), Integer), CType(CType(45, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.BtnBarNormal.CLROver1 = System.Drawing.Color.FromArgb(CType(CType(45, Byte), Integer), CType(CType(45, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.BtnBarNormal.CLROverbrd = System.Drawing.Color.FromArgb(CType(CType(85, Byte), Integer), CType(CType(85, Byte), Integer), CType(CType(85, Byte), Integer))
        Me.BtnBarNormal.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Bold)
        Me.BtnBarNormal.ImageChoice = Nothing
        Me.BtnBarNormal.Location = New System.Drawing.Point(18, 13)
        Me.BtnBarNormal.Name = "BtnBarNormal"
        Me.BtnBarNormal.ShowImage = False
        Me.BtnBarNormal.Size = New System.Drawing.Size(65, 65)
        Me.BtnBarNormal.TabIndex = 3
        Me.BtnBarNormal.Text = "ThemeBtnBar1"
        '
        'TabPage4
        '
        Me.TabPage4.BackColor = System.Drawing.Color.FromArgb(CType(CType(37, Byte), Integer), CType(CType(37, Byte), Integer), CType(CType(38, Byte), Integer))
        Me.TabPage4.Controls.Add(Me.PNLAdmin)
        Me.TabPage4.Location = New System.Drawing.Point(4, 54)
        Me.TabPage4.Name = "TabPage4"
        Me.TabPage4.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage4.Size = New System.Drawing.Size(335, 323)
        Me.TabPage4.TabIndex = 3
        Me.TabPage4.Text = "Device Policy Manager"
        '
        'PNLAdmin
        '
        Me.PNLAdmin.BackColor = System.Drawing.Color.FromArgb(CType(CType(45, Byte), Integer), CType(CType(45, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.PNLAdmin.Controls.Add(Me.LABKEY)
        Me.PNLAdmin.Controls.Add(Me.LABresetPassword)
        Me.PNLAdmin.Controls.Add(Me.BRNresetPassword)
        Me.PNLAdmin.Controls.Add(Me.LABwipeData)
        Me.PNLAdmin.Controls.Add(Me.BTNwipeData)
        Me.PNLAdmin.Controls.Add(Me.LBFLlockNow)
        Me.PNLAdmin.Controls.Add(Me.BTNlockNow)
        Me.PNLAdmin.Dock = System.Windows.Forms.DockStyle.Fill
        Me.PNLAdmin.Location = New System.Drawing.Point(3, 3)
        Me.PNLAdmin.Name = "PNLAdmin"
        Me.PNLAdmin.Size = New System.Drawing.Size(329, 317)
        Me.PNLAdmin.TabIndex = 0
        '
        'LABKEY
        '
        Me.LABKEY.AutoSize = True
        Me.LABKEY.Font = New System.Drawing.Font("Segoe UI Semibold", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LABKEY.ForeColor = System.Drawing.Color.PaleGreen
        Me.LABKEY.Location = New System.Drawing.Point(63, 140)
        Me.LABKEY.Name = "LABKEY"
        Me.LABKEY.Size = New System.Drawing.Size(27, 15)
        Me.LABKEY.TabIndex = 25
        Me.LABKEY.Text = "KEY"
        '
        'LABresetPassword
        '
        Me.LABresetPassword.AutoSize = True
        Me.LABresetPassword.Font = New System.Drawing.Font("Segoe UI Semibold", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LABresetPassword.ForeColor = System.Drawing.Color.FromArgb(CType(CType(241, Byte), Integer), CType(CType(241, Byte), Integer), CType(CType(241, Byte), Integer))
        Me.LABresetPassword.Location = New System.Drawing.Point(61, 119)
        Me.LABresetPassword.Name = "LABresetPassword"
        Me.LABresetPassword.Size = New System.Drawing.Size(153, 15)
        Me.LABresetPassword.TabIndex = 24
        Me.LABresetPassword.Text = "Add a screen lock password"
        '
        'BRNresetPassword
        '
        Me.BRNresetPassword.BackColorDown0_S = System.Drawing.Color.FromArgb(CType(CType(30, Byte), Integer), CType(CType(30, Byte), Integer), CType(CType(30, Byte), Integer))
        Me.BRNresetPassword.BackColorDown1_S = System.Drawing.Color.FromArgb(CType(CType(30, Byte), Integer), CType(CType(30, Byte), Integer), CType(CType(30, Byte), Integer))
        Me.BRNresetPassword.BackColorNone0_S = System.Drawing.Color.FromArgb(CType(CType(37, Byte), Integer), CType(CType(37, Byte), Integer), CType(CType(38, Byte), Integer))
        Me.BRNresetPassword.BackColorNone1_S = System.Drawing.Color.FromArgb(CType(CType(37, Byte), Integer), CType(CType(37, Byte), Integer), CType(CType(38, Byte), Integer))
        Me.BRNresetPassword.BackColorOver0_S = System.Drawing.Color.FromArgb(CType(CType(45, Byte), Integer), CType(CType(45, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.BRNresetPassword.BackColorOver1_S = System.Drawing.Color.FromArgb(CType(CType(45, Byte), Integer), CType(CType(45, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.BRNresetPassword.ButtonBackColorEnabled0_S = System.Drawing.Color.FromArgb(CType(CType(53, Byte), Integer), CType(CType(53, Byte), Integer), CType(CType(60, Byte), Integer))
        Me.BRNresetPassword.ButtonBackColorEnabled1_S = System.Drawing.Color.FromArgb(CType(CType(53, Byte), Integer), CType(CType(53, Byte), Integer), CType(CType(60, Byte), Integer))
        Me.BRNresetPassword.ButtonForColor_S = System.Drawing.Color.FromArgb(CType(CType(174, Byte), Integer), CType(CType(174, Byte), Integer), CType(CType(174, Byte), Integer))
        Me.BRNresetPassword.ButtonForColorEnabled_S = System.Drawing.Color.FromArgb(CType(CType(83, Byte), Integer), CType(CType(83, Byte), Integer), CType(CType(90, Byte), Integer))
        Me.BRNresetPassword.Buttonselected_Color_ForColor_S = System.Drawing.Color.FromArgb(CType(CType(214, Byte), Integer), CType(CType(214, Byte), Integer), CType(CType(214, Byte), Integer))
        Me.BRNresetPassword.Font = New System.Drawing.Font("Segoe UI Semibold", 9.0!)
        Me.BRNresetPassword.ForeColor = System.Drawing.Color.White
        Me.BRNresetPassword.ImageAlignment = SpyNote_V6._4.SN.ThemeButton.__ImageAlignment.Left
        Me.BRNresetPassword.ImageChoice = Nothing
        Me.BRNresetPassword.Location = New System.Drawing.Point(11, 113)
        Me.BRNresetPassword.Name = "BRNresetPassword"
        Me.BRNresetPassword.ShowImage = False
        Me.BRNresetPassword.ShowText = False
        Me.BRNresetPassword.Size = New System.Drawing.Size(20, 20)
        Me.BRNresetPassword.TabIndex = 23
        Me.BRNresetPassword.Tag = "0"
        Me.BRNresetPassword.TextAlignment = System.Drawing.StringAlignment.Center
        Me.BRNresetPassword.ThemeButtonclrBorder_S = System.Drawing.Color.FromArgb(CType(CType(53, Byte), Integer), CType(CType(53, Byte), Integer), CType(CType(60, Byte), Integer))
        Me.BRNresetPassword.ThemeButtonclrBorderactive_S = System.Drawing.Color.FromArgb(CType(CType(56, Byte), Integer), CType(CType(56, Byte), Integer), CType(CType(63, Byte), Integer))
        Me.BRNresetPassword.ThemeButtonclrBorderEnabled_S = System.Drawing.Color.FromArgb(CType(CType(68, Byte), Integer), CType(CType(68, Byte), Integer), CType(CType(75, Byte), Integer))
        '
        'LABwipeData
        '
        Me.LABwipeData.AutoSize = True
        Me.LABwipeData.Font = New System.Drawing.Font("Segoe UI Semibold", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LABwipeData.ForeColor = System.Drawing.Color.FromArgb(CType(CType(241, Byte), Integer), CType(CType(241, Byte), Integer), CType(CType(241, Byte), Integer))
        Me.LABwipeData.Location = New System.Drawing.Point(61, 78)
        Me.LABwipeData.Name = "LABwipeData"
        Me.LABwipeData.Size = New System.Drawing.Size(74, 15)
        Me.LABwipeData.TabIndex = 22
        Me.LABwipeData.Text = "Factory reset"
        '
        'BTNwipeData
        '
        Me.BTNwipeData.BackColorDown0_S = System.Drawing.Color.FromArgb(CType(CType(30, Byte), Integer), CType(CType(30, Byte), Integer), CType(CType(30, Byte), Integer))
        Me.BTNwipeData.BackColorDown1_S = System.Drawing.Color.FromArgb(CType(CType(30, Byte), Integer), CType(CType(30, Byte), Integer), CType(CType(30, Byte), Integer))
        Me.BTNwipeData.BackColorNone0_S = System.Drawing.Color.FromArgb(CType(CType(37, Byte), Integer), CType(CType(37, Byte), Integer), CType(CType(38, Byte), Integer))
        Me.BTNwipeData.BackColorNone1_S = System.Drawing.Color.FromArgb(CType(CType(37, Byte), Integer), CType(CType(37, Byte), Integer), CType(CType(38, Byte), Integer))
        Me.BTNwipeData.BackColorOver0_S = System.Drawing.Color.FromArgb(CType(CType(45, Byte), Integer), CType(CType(45, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.BTNwipeData.BackColorOver1_S = System.Drawing.Color.FromArgb(CType(CType(45, Byte), Integer), CType(CType(45, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.BTNwipeData.ButtonBackColorEnabled0_S = System.Drawing.Color.FromArgb(CType(CType(53, Byte), Integer), CType(CType(53, Byte), Integer), CType(CType(60, Byte), Integer))
        Me.BTNwipeData.ButtonBackColorEnabled1_S = System.Drawing.Color.FromArgb(CType(CType(53, Byte), Integer), CType(CType(53, Byte), Integer), CType(CType(60, Byte), Integer))
        Me.BTNwipeData.ButtonForColor_S = System.Drawing.Color.FromArgb(CType(CType(174, Byte), Integer), CType(CType(174, Byte), Integer), CType(CType(174, Byte), Integer))
        Me.BTNwipeData.ButtonForColorEnabled_S = System.Drawing.Color.FromArgb(CType(CType(83, Byte), Integer), CType(CType(83, Byte), Integer), CType(CType(90, Byte), Integer))
        Me.BTNwipeData.Buttonselected_Color_ForColor_S = System.Drawing.Color.FromArgb(CType(CType(214, Byte), Integer), CType(CType(214, Byte), Integer), CType(CType(214, Byte), Integer))
        Me.BTNwipeData.Font = New System.Drawing.Font("Segoe UI Semibold", 9.0!)
        Me.BTNwipeData.ForeColor = System.Drawing.Color.White
        Me.BTNwipeData.ImageAlignment = SpyNote_V6._4.SN.ThemeButton.__ImageAlignment.Left
        Me.BTNwipeData.ImageChoice = Nothing
        Me.BTNwipeData.Location = New System.Drawing.Point(11, 72)
        Me.BTNwipeData.Name = "BTNwipeData"
        Me.BTNwipeData.ShowImage = False
        Me.BTNwipeData.ShowText = False
        Me.BTNwipeData.Size = New System.Drawing.Size(20, 20)
        Me.BTNwipeData.TabIndex = 21
        Me.BTNwipeData.Tag = "0"
        Me.BTNwipeData.TextAlignment = System.Drawing.StringAlignment.Center
        Me.BTNwipeData.ThemeButtonclrBorder_S = System.Drawing.Color.FromArgb(CType(CType(53, Byte), Integer), CType(CType(53, Byte), Integer), CType(CType(60, Byte), Integer))
        Me.BTNwipeData.ThemeButtonclrBorderactive_S = System.Drawing.Color.FromArgb(CType(CType(56, Byte), Integer), CType(CType(56, Byte), Integer), CType(CType(63, Byte), Integer))
        Me.BTNwipeData.ThemeButtonclrBorderEnabled_S = System.Drawing.Color.FromArgb(CType(CType(68, Byte), Integer), CType(CType(68, Byte), Integer), CType(CType(75, Byte), Integer))
        '
        'LBFLlockNow
        '
        Me.LBFLlockNow.AutoSize = True
        Me.LBFLlockNow.Font = New System.Drawing.Font("Segoe UI Semibold", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LBFLlockNow.ForeColor = System.Drawing.Color.FromArgb(CType(CType(241, Byte), Integer), CType(CType(241, Byte), Integer), CType(CType(241, Byte), Integer))
        Me.LBFLlockNow.Location = New System.Drawing.Point(61, 40)
        Me.LBFLlockNow.Name = "LBFLlockNow"
        Me.LBFLlockNow.Size = New System.Drawing.Size(71, 15)
        Me.LBFLlockNow.TabIndex = 20
        Me.LBFLlockNow.Text = "Screen Lock"
        '
        'BTNlockNow
        '
        Me.BTNlockNow.BackColorDown0_S = System.Drawing.Color.FromArgb(CType(CType(30, Byte), Integer), CType(CType(30, Byte), Integer), CType(CType(30, Byte), Integer))
        Me.BTNlockNow.BackColorDown1_S = System.Drawing.Color.FromArgb(CType(CType(30, Byte), Integer), CType(CType(30, Byte), Integer), CType(CType(30, Byte), Integer))
        Me.BTNlockNow.BackColorNone0_S = System.Drawing.Color.FromArgb(CType(CType(37, Byte), Integer), CType(CType(37, Byte), Integer), CType(CType(38, Byte), Integer))
        Me.BTNlockNow.BackColorNone1_S = System.Drawing.Color.FromArgb(CType(CType(37, Byte), Integer), CType(CType(37, Byte), Integer), CType(CType(38, Byte), Integer))
        Me.BTNlockNow.BackColorOver0_S = System.Drawing.Color.FromArgb(CType(CType(45, Byte), Integer), CType(CType(45, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.BTNlockNow.BackColorOver1_S = System.Drawing.Color.FromArgb(CType(CType(45, Byte), Integer), CType(CType(45, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.BTNlockNow.ButtonBackColorEnabled0_S = System.Drawing.Color.FromArgb(CType(CType(53, Byte), Integer), CType(CType(53, Byte), Integer), CType(CType(60, Byte), Integer))
        Me.BTNlockNow.ButtonBackColorEnabled1_S = System.Drawing.Color.FromArgb(CType(CType(53, Byte), Integer), CType(CType(53, Byte), Integer), CType(CType(60, Byte), Integer))
        Me.BTNlockNow.ButtonForColor_S = System.Drawing.Color.FromArgb(CType(CType(174, Byte), Integer), CType(CType(174, Byte), Integer), CType(CType(174, Byte), Integer))
        Me.BTNlockNow.ButtonForColorEnabled_S = System.Drawing.Color.FromArgb(CType(CType(83, Byte), Integer), CType(CType(83, Byte), Integer), CType(CType(90, Byte), Integer))
        Me.BTNlockNow.Buttonselected_Color_ForColor_S = System.Drawing.Color.FromArgb(CType(CType(214, Byte), Integer), CType(CType(214, Byte), Integer), CType(CType(214, Byte), Integer))
        Me.BTNlockNow.Font = New System.Drawing.Font("Segoe UI Semibold", 9.0!)
        Me.BTNlockNow.ForeColor = System.Drawing.Color.White
        Me.BTNlockNow.ImageAlignment = SpyNote_V6._4.SN.ThemeButton.__ImageAlignment.Left
        Me.BTNlockNow.ImageChoice = Nothing
        Me.BTNlockNow.Location = New System.Drawing.Point(11, 34)
        Me.BTNlockNow.Name = "BTNlockNow"
        Me.BTNlockNow.ShowImage = False
        Me.BTNlockNow.ShowText = False
        Me.BTNlockNow.Size = New System.Drawing.Size(20, 20)
        Me.BTNlockNow.TabIndex = 12
        Me.BTNlockNow.Tag = "0"
        Me.BTNlockNow.TextAlignment = System.Drawing.StringAlignment.Center
        Me.BTNlockNow.ThemeButtonclrBorder_S = System.Drawing.Color.FromArgb(CType(CType(53, Byte), Integer), CType(CType(53, Byte), Integer), CType(CType(60, Byte), Integer))
        Me.BTNlockNow.ThemeButtonclrBorderactive_S = System.Drawing.Color.FromArgb(CType(CType(56, Byte), Integer), CType(CType(56, Byte), Integer), CType(CType(63, Byte), Integer))
        Me.BTNlockNow.ThemeButtonclrBorderEnabled_S = System.Drawing.Color.FromArgb(CType(CType(68, Byte), Integer), CType(CType(68, Byte), Integer), CType(CType(75, Byte), Integer))
        '
        'TScrolls
        '
        Me.TScrolls.Interval = 1
        '
        'TProgressBar
        '
        Me.TProgressBar.Interval = 1
        '
        'Trans
        '
        Me.Trans.Interval = 40
        '
        'FSettings
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.FromArgb(CType(CType(45, Byte), Integer), CType(CType(45, Byte), Integer), CType(CType(48, Byte), Integer))
        Me.ClientSize = New System.Drawing.Size(343, 444)
        Me.Controls.Add(Me.ThemeTabControl1)
        Me.Controls.Add(Me.Panel1)
        Me.Controls.Add(Me.PNLERRORS)
        Me.Controls.Add(Me.ProgressBar1)
        Me.ForeColor = System.Drawing.Color.FromArgb(CType(CType(170, Byte), Integer), CType(CType(170, Byte), Integer), CType(CType(170, Byte), Integer))
        Me.Name = "FSettings"
        Me.Opacity = 0R
        Me.Text = "FSettings"
        Me.PNLERRORS.ResumeLayout(False)
        Me.PNLERRORS.PerformLayout()
        Me.Panel1.ResumeLayout(False)
        Me.ThemeTabControl1.ResumeLayout(False)
        Me.TabPage1.ResumeLayout(False)
        Me.PINFO.ResumeLayout(False)
        CType(Me.ViewManager, System.ComponentModel.ISupportInitialize).EndInit()
        Me.TabPage2.ResumeLayout(False)
        Me.PanelSystem.ResumeLayout(False)
        Me.PanelSystem.PerformLayout()
        Me.PanelNotification.ResumeLayout(False)
        Me.PanelNotification.PerformLayout()
        Me.PanelMedia.ResumeLayout(False)
        Me.PanelMedia.PerformLayout()
        Me.PanelRingtone.ResumeLayout(False)
        Me.PanelRingtone.PerformLayout()
        Me.TabPage3.ResumeLayout(False)
        Me.PanelBar.ResumeLayout(False)
        Me.PanelBar.PerformLayout()
        Me.TabPage4.ResumeLayout(False)
        Me.PNLAdmin.ResumeLayout(False)
        Me.PNLAdmin.PerformLayout()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents ProgressBar1 As SN.ThemeProgressBar
    Friend WithEvents PNLERRORS As Panel
    Friend WithEvents LBER As Label
    Friend WithEvents Panel1 As Panel
    Friend WithEvents BtnOK As SN.ThemeButton
    Friend WithEvents ThemeTabControl1 As SN.ThemeTabControl
    Friend WithEvents TabPage1 As TabPage
    Friend WithEvents TabPage2 As TabPage
    Friend WithEvents PINFO As Panel
    Friend WithEvents VisualStudioVerticalScrollBar1 As SN.VisualStudioVerticalScrollBar
    Friend WithEvents VisualStudioHorizontalScrollBar1 As SN.VisualStudioHorizontalScrollBar
    Friend WithEvents ViewManager As DataGridView
    Friend WithEvents Column1 As DataGridViewImageColumn
    Friend WithEvents Column2 As DataGridViewTextBoxColumn
    Friend WithEvents PanelRingtone As Panel
    Friend WithEvents LabelRingtone As Label
    Friend WithEvents TrackRingtone As SN.Track
    Friend WithEvents TSEP1 As SN.ThemeSeparator
    Friend WithEvents PanelMedia As Panel
    Friend WithEvents TrackMedia As SN.Track
    Friend WithEvents LabelMedia As Label
    Friend WithEvents PanelSystem As Panel
    Friend WithEvents ThemeSeparator3 As SN.ThemeSeparator
    Friend WithEvents TrackSystem As SN.Track
    Friend WithEvents LabelSystem As Label
    Friend WithEvents PanelNotification As Panel
    Friend WithEvents ThemeSeparator2 As SN.ThemeSeparator
    Friend WithEvents TrackNotification As SN.Track
    Friend WithEvents LabelNotification As Label
    Friend WithEvents ThemeSeparator1 As SN.ThemeSeparator
    Friend WithEvents TabPage3 As TabPage
    Friend WithEvents PanelBar As Panel
    Friend WithEvents BtnBarMobileData As SN.ThemeBtnBar
    Friend WithEvents BtnBarGps As SN.ThemeBtnBar
    Friend WithEvents BtnBarBluetooth As SN.ThemeBtnBar
    Friend WithEvents BtnBarSilent As SN.ThemeBtnBar
    Friend WithEvents BtnBarVibrate As SN.ThemeBtnBar
    Friend WithEvents BtnBarNormal As SN.ThemeBtnBar
    Friend WithEvents BtnBarWifirest As SN.ThemeBtnBar
    Friend WithEvents BtnBarWifiDisconnect As SN.ThemeBtnBar
    Friend WithEvents BtnBarWifiConnected As SN.ThemeBtnBar
    Friend WithEvents LabBarMobileData As Label
    Friend WithEvents LabBarGps As Label
    Friend WithEvents LabBarBluetooth As Label
    Friend WithEvents LabBarSilent As Label
    Friend WithEvents LabBarVibrate As Label
    Friend WithEvents LabBarNormal As Label
    Friend WithEvents LabBarWifirest As Label
    Friend WithEvents LabBarWifiDisconnect As Label
    Friend WithEvents LabBarWifiConnected As Label
    Friend WithEvents ThemeSeparator5 As SN.ThemeSeparator
    Friend WithEvents ThemeSeparator4 As SN.ThemeSeparator
    Friend WithEvents TabPage4 As TabPage
    Friend WithEvents PNLAdmin As Panel
    Friend WithEvents LABwipeData As Label
    Friend WithEvents BTNwipeData As SN.ThemeButton
    Friend WithEvents LBFLlockNow As Label
    Friend WithEvents BTNlockNow As SN.ThemeButton
    Friend WithEvents LABresetPassword As Label
    Friend WithEvents BRNresetPassword As SN.ThemeButton
    Friend WithEvents LABKEY As Label
    Friend WithEvents TScrolls As Timer
    Friend WithEvents TProgressBar As Timer
    Friend WithEvents Trans As Timer
End Class
